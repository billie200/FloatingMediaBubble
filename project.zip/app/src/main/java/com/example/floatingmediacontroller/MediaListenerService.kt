package com.example.floatingmediacontroller

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

/**
 * Connects to Android's MediaSessionManager to track active media playback across
 * Spotify, YouTube Music, Apple Music, browsers, podcasts, and local players.
 */
class MediaListenerService : NotificationListenerService() {

    private var mediaSessionManager: MediaSessionManager? = null
    private lateinit var componentName: ComponentName

    private val activeSessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            selectBestController(controllers)
        }

    override fun onCreate() {
        super.onCreate()
        componentName = ComponentName(this, MediaListenerService::class.java)
        mediaSessionManager =
            getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshSessions()
        try {
            mediaSessionManager?.addOnActiveSessionsChangedListener(
                activeSessionsListener,
                componentName
            )
        } catch (_: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(activeSessionsListener)
        } catch (_: Exception) {
        }
        MediaSessionBridge.setController(null)
    }

    override fun onDestroy() {
        try {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(activeSessionsListener)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun refreshSessions() {
        try {
            val controllers = mediaSessionManager?.getActiveSessions(componentName)
            selectBestController(controllers)
        } catch (_: SecurityException) {
            MediaSessionBridge.setController(null)
        }
    }

    private fun selectBestController(controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) {
            MediaSessionBridge.setController(null)
            return
        }
        // Prefer whichever session is actively playing; otherwise pick the first active session
        val playingController = controllers.firstOrNull {
            val state = it.playbackState?.state
            state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING
        }
        MediaSessionBridge.setController(playingController ?: controllers.first())
    }
}
