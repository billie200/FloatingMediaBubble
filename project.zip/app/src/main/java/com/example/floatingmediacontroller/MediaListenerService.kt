package com.example.floatingmediacontroller

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService

class MediaListenerService : NotificationListenerService() {

    companion object {
        fun ensureConnected(context: Context) {
            try {
                val cn = ComponentName(context, MediaListenerService::class.java)
                requestRebind(cn)
            } catch (_: Throwable) {
            }
        }
    }

    private var mediaSessionManager: MediaSessionManager? = null
    private lateinit var componentName: ComponentName

    private val activeSessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            MediaSessionBridge.updateControllersList(
                this,
                controllers ?: emptyList()
            )
        }

    override fun onCreate() {
        super.onCreate()
        componentName = ComponentName(this, MediaListenerService::class.java)
        mediaSessionManager =
            getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshSessions()
        try {
            mediaSessionManager?.addOnActiveSessionsChangedListener(
                activeSessionsListener,
                componentName
            )
        } catch (_: Throwable) {
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(activeSessionsListener)
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        try {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(activeSessionsListener)
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    private fun refreshSessions() {
        try {
            val controllers: List<MediaController> =
                mediaSessionManager?.getActiveSessions(componentName) ?: emptyList()
            MediaSessionBridge.updateControllersList(this, controllers)
        } catch (_: Throwable) {
        }
    }
}
