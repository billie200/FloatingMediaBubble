package com.example.floatingmediacontroller

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvNotificationStatus: TextView
    private lateinit var btnGrantOverlay: Button
    private lateinit var btnGrantNotification: Button

    private lateinit var rgSessions: RadioGroup
    private lateinit var btnRefreshSessions: Button

    private lateinit var seekScale: SeekBar
    private lateinit var tvScaleValue: TextView
    private lateinit var seekOpacity: SeekBar
    private lateinit var tvOpacityValue: TextView
    private lateinit var cbBurnIn: CheckBox
    private lateinit var themeChipsContainer: LinearLayout

    private lateinit var btnLaunchBubble: Button
    private lateinit var btnStopBubble: Button

    private val sessionListListener: (List<MediaSessionBridge.SessionEntry>) -> Unit = { entries ->
        rebuildSessionRadioButtons(entries)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvNotificationStatus = findViewById(R.id.tvNotificationStatus)
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay)
        btnGrantNotification = findViewById(R.id.btnGrantNotification)

        rgSessions = findViewById(R.id.rgSessions)
        btnRefreshSessions = findViewById(R.id.btnRefreshSessions)

        seekScale = findViewById(R.id.seekScale)
        tvScaleValue = findViewById(R.id.tvScaleValue)
        seekOpacity = findViewById(R.id.seekOpacity)
        tvOpacityValue = findViewById(R.id.tvOpacityValue)
        cbBurnIn = findViewById(R.id.cbBurnIn)
        themeChipsContainer = findViewById(R.id.themeChipsContainer)

        btnLaunchBubble = findViewById(R.id.btnLaunchBubble)
        btnStopBubble = findViewById(R.id.btnStopBubble)

        setupPermissionsButtons()
        setupSessionPicker()
        setupAppearanceControls()
        setupLaunchButtons()

        requestPostNotificationsIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatusUi()
        MediaSessionBridge.registerSessionListListener(sessionListListener)
        if (isNotificationListenerEnabled()) {
            MediaListenerService.ensureConnected(this)
            MediaSessionBridge.pollActiveSessions(this)
        }
    }

    override fun onPause() {
        MediaSessionBridge.unregisterSessionListListener(sessionListListener)
        super.onPause()
    }

    private fun setupPermissionsButtons() {
        btnGrantOverlay.setOnClickListener {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
        }

        btnGrantNotification.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Throwable) {
            }
        }
    }

    private fun setupSessionPicker() {
        btnRefreshSessions.setOnClickListener {
            if (!isNotificationListenerEnabled()) {
                Toast.makeText(this, getString(R.string.msg_enable_listener_first), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            MediaListenerService.ensureConnected(this)
            MediaSessionBridge.pollActiveSessions(this)
            Toast.makeText(this, "Refreshed active media sessions", Toast.LENGTH_SHORT).show()
        }
    }

    private fun rebuildSessionRadioButtons(entries: List<MediaSessionBridge.SessionEntry>) {
        val currentTarget = BubblePrefs.getTargetPackage(this)
        rgSessions.setOnCheckedChangeListener(null)
        rgSessions.removeAllViews()

        val autoRb = RadioButton(this).apply {
            id = View.generateViewId()
            text = "Auto (Follow currently playing app)"
            setTextColor(Color.parseColor("#F3F4F6"))
            textSize = 14f
            tag = ""
            isChecked = currentTarget.isBlank()
        }
        rgSessions.addView(autoRb)

        entries.forEach { entry ->
            val status = if (entry.isPlaying) "▶ Playing" else "⏸ Paused"
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = "${entry.appLabel} ($status — ${entry.title})"
                setTextColor(Color.parseColor("#E5E7EB"))
                textSize = 13.5f
                tag = entry.packageName
                isChecked = (currentTarget == entry.packageName)
            }
            rgSessions.addView(rb)
        }

        rgSessions.setOnCheckedChangeListener { group, checkedId ->
            val selected = group.findViewById<RadioButton>(checkedId) ?: return@setOnCheckedChangeListener
            val pkg = selected.tag as? String ?: ""
            BubblePrefs.setTargetPackage(this, pkg)
            MediaSessionBridge.forceRefreshUi(this)
            notifyServiceStyleChanged()
        }
    }

    private fun setupAppearanceControls() {
        val currentScale = BubblePrefs.getScalePercent(this)
        seekScale.max = 75 // 70%..145%
        seekScale.progress = (currentScale - 70).coerceIn(0, 75)
        tvScaleValue.text = "Bubble Size Scale: $currentScale%"

        seekScale.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val pct = (progress + 70).coerceIn(70, 145)
                tvScaleValue.text = "Bubble Size Scale: $pct%"
                BubblePrefs.setScalePercent(this@MainActivity, pct)
                notifyServiceStyleChanged()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        val currentOpacity = BubblePrefs.getOpacityPercent(this)
        seekOpacity.max = 85
        seekOpacity.progress = (currentOpacity - 15).coerceIn(0, 85)
        tvOpacityValue.text = "Bubble & Album Art Opacity: $currentOpacity%"

        seekOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val pct = (progress + 15).coerceIn(15, 100)
                tvOpacityValue.text = "Bubble & Album Art Opacity: $pct%"
                BubblePrefs.setOpacityPercent(this@MainActivity, pct)
                notifyServiceStyleChanged()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        cbBurnIn.isChecked = BubblePrefs.isBurnInProtectionEnabled(this)
        cbBurnIn.setOnCheckedChangeListener { _, checked ->
            BubblePrefs.setBurnInProtectionEnabled(this, checked)
            notifyServiceStyleChanged()
        }

        buildThemeSelectorButtons()
    }

    private fun buildThemeSelectorButtons() {
        themeChipsContainer.removeAllViews()
        val themes = listOf(
            Triple(BubblePrefs.THEME_ALBUM_ART, "Album Art Adaptive (M3)", "#8B5CF6"),
            Triple(BubblePrefs.THEME_MATERIAL_YOU, "System Material You", "#3B82F6"),
            Triple(BubblePrefs.THEME_VIOLET, "Electric Violet", "#A855F7"),
            Triple(BubblePrefs.THEME_EMERALD, "Cyber Emerald", "#10B981"),
            Triple(BubblePrefs.THEME_ROSE, "Crimson Rose", "#F43F5E"),
            Triple(BubblePrefs.THEME_AMBER, "Solar Amber", "#F59E0B"),
            Triple(BubblePrefs.THEME_CYAN, "Neon Cyan", "#06B6D4"),
            Triple(BubblePrefs.THEME_MONOCHROME, "Minimal OLED Frost", "#E5E7EB")
        )

        val selectedMode = BubblePrefs.getThemeMode(this)
        val density = resources.displayMetrics.density

        themes.forEach { (mode, label, hex) ->
            val isSelected = (mode == selectedMode)
            val btn = Button(this).apply {
                text = if (isSelected) "✓ $label" else label
                isAllCaps = false
                textSize = 13f
                setTextColor(Color.parseColor("#FFFFFF"))
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f * density
                    val baseColor = Color.parseColor(hex)
                    setColor(
                        Color.argb(
                            if (isSelected) 115 else 45,
                            Color.red(baseColor),
                            Color.green(baseColor),
                            Color.blue(baseColor)
                        )
                    )
                    setStroke(
                        ((if (isSelected) 2.2f else 1f) * density).toInt(),
                        baseColor
                    )
                }
                background = bg
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (44 * density).toInt()
                ).apply {
                    topMargin = (6 * density).toInt()
                }
                layoutParams = lp
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
                setPadding((14 * density).toInt(), 0, (14 * density).toInt(), 0)
                setOnClickListener {
                    BubblePrefs.setThemeMode(this@MainActivity, mode)
                    buildThemeSelectorButtons()
                    notifyServiceStyleChanged()
                }
            }
            themeChipsContainer.addView(btn)
        }
    }

    private fun setupLaunchButtons() {
        btnLaunchBubble.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, getString(R.string.msg_enable_overlay_first), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!isNotificationListenerEnabled()) {
                Toast.makeText(this, getString(R.string.msg_enable_listener_first), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                MediaListenerService.ensureConnected(this)
                MediaSessionBridge.pollActiveSessions(this)

                val serviceIntent = Intent(this, FloatingWidgetService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
                Toast.makeText(this, getString(R.string.msg_bubble_started), Toast.LENGTH_SHORT).show()
                finish()
            } catch (t: Throwable) {
                Toast.makeText(this, "Error: ${t.message}", Toast.LENGTH_LONG).show()
            }
        }

        btnStopBubble.setOnClickListener {
            val stopIntent = Intent(this, FloatingWidgetService::class.java)
            stopService(stopIntent)
            Toast.makeText(this, getString(R.string.toast_bubble_closed), Toast.LENGTH_SHORT).show()
        }
    }

    private fun notifyServiceStyleChanged() {
        if (Settings.canDrawOverlays(this)) {
            val intent = Intent(this, FloatingWidgetService::class.java).apply {
                action = FloatingWidgetService.ACTION_REFRESH_STYLE
            }
            try {
                startService(intent)
            } catch (_: Throwable) {
            }
        }
    }

    private fun updatePermissionStatusUi() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val hasListener = isNotificationListenerEnabled()

        tvOverlayStatus.text = if (hasOverlay) {
            getString(R.string.status_overlay_granted)
        } else {
            getString(R.string.status_overlay_missing)
        }

        tvNotificationStatus.text = if (hasListener) {
            getString(R.string.status_listener_granted)
        } else {
            getString(R.string.status_listener_missing)
        }

        btnGrantOverlay.isEnabled = !hasOverlay
        btnGrantNotification.isEnabled = !hasListener
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val cn = ComponentName(this, MediaListenerService::class.java)
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(cn.flattenToString())
    }

    private fun requestPostNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }
}
