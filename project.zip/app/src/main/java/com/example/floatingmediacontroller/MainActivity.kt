package com.example.floatingmediacontroller

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvNotificationStatus: TextView
    private lateinit var btnGrantOverlay: MaterialButton
    private lateinit var btnGrantNotification: MaterialButton
    private lateinit var btnLaunchBubble: MaterialButton
    private lateinit var btnStopBubble: MaterialButton

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        updatePermissionStatusUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvNotificationStatus = findViewById(R.id.tvNotificationStatus)
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay)
        btnGrantNotification = findViewById(R.id.btnGrantNotification)
        btnLaunchBubble = findViewById(R.id.btnLaunchBubble)
        btnStopBubble = findViewById(R.id.btnStopBubble)

        btnGrantOverlay.setOnClickListener {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
        }

        btnGrantNotification.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Throwable) {
            }
        }

        btnLaunchBubble.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    getString(R.string.msg_enable_overlay_first),
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            if (!isNotificationListenerEnabled()) {
                Toast.makeText(
                    this,
                    getString(R.string.msg_enable_listener_first),
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            try {
                MediaListenerService.ensureConnected(this)
                MediaSessionBridge.pollActiveSessions(this)

                val serviceIntent = Intent(this, FloatingWidgetService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
                Toast.makeText(
                    this,
                    getString(R.string.msg_bubble_started),
                    Toast.LENGTH_SHORT
                ).show()
            } catch (t: Throwable) {
                Toast.makeText(
                    this,
                    "Error starting bubble: ${t.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        btnStopBubble.setOnClickListener {
            val stopIntent = Intent(this, FloatingWidgetService::class.java)
            stopService(stopIntent)
            Toast.makeText(
                this,
                getString(R.string.toast_bubble_closed),
                Toast.LENGTH_SHORT
            ).show()
        }

        requestPostNotificationsIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatusUi()
        if (isNotificationListenerEnabled()) {
            MediaListenerService.ensureConnected(this)
            MediaSessionBridge.pollActiveSessions(this)
        }
    }

    private fun updatePermissionStatusUi() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val hasListener = isNotificationListenerEnabled()

        tvOverlayStatus.text = if (hasOverlay) {
            getString(R.string.status_overlay_granted)
        } else {
            getString(R.string.status_overlay_missing)
        }

        tvNotificationStatus.text = if (hasListener) {
            getString(R.string.status_listener_granted)
        } else {
            getString(R.string.status_listener_missing)
        }

        btnGrantOverlay.isEnabled = !hasOverlay
        btnGrantNotification.isEnabled = !hasListener
        btnLaunchBubble.isEnabled = true
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val cn = ComponentName(this, MediaListenerService::class.java)
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(cn.flattenToString())
    }

    private fun requestPostNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
