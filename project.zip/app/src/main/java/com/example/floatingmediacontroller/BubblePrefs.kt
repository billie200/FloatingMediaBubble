package com.example.floatingmediacontroller

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build

object BubblePrefs {
    private const val PREFS_NAME = "floating_bubble_prefs"
    private const val KEY_OPACITY = "opacity_percent"           // 15..100 (default 85)
    private const val KEY_SCALE = "scale_percent"               // 70..145 (default 100)
    private const val KEY_BURN_IN = "oled_burn_in_protection"   // true by default
    private const val KEY_THEME_MODE = "theme_mode"             // 0=Album Art Auto, 1=Material You System, 2..7=Custom Presets
    private const val KEY_TARGET_PKG = "target_package"         // "" = Auto (Playing app), or specific packageName

    const val THEME_ALBUM_ART = 0
    const val THEME_MATERIAL_YOU = 1
    const val THEME_VIOLET = 2
    const val THEME_EMERALD = 3
    const val THEME_ROSE = 4
    const val THEME_AMBER = 5
    const val THEME_CYAN = 6
    const val THEME_MONOCHROME = 7

    data class ThemePalette(
        val cardSurfaceColor: Int,
        val strokeColor: Int,
        val accentColor: Int,
        val onAccentColor: Int,
        val primaryTextColor: Int,
        val secondaryTextColor: Int,
        val opacityAlpha: Int
    )

    fun getOpacityPercent(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_OPACITY, 85)
            .coerceIn(15, 100)
    }

    fun setOpacityPercent(context: Context, percent: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_OPACITY, percent.coerceIn(15, 100))
            .apply()
    }

    fun getScalePercent(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SCALE, 100)
            .coerceIn(70, 145)
    }

    fun setScalePercent(context: Context, percent: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SCALE, percent.coerceIn(70, 145))
            .apply()
    }

    fun isBurnInProtectionEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_BURN_IN, true)
    }

    fun setBurnInProtectionEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_BURN_IN, enabled)
            .apply()
    }

    fun getThemeMode(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_THEME_MODE, THEME_ALBUM_ART)
    }

    fun setThemeMode(context: Context, mode: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_THEME_MODE, mode)
            .apply()
    }

    fun getTargetPackage(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TARGET_PKG, "") ?: ""
    }

    fun setTargetPackage(context: Context, pkg: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TARGET_PKG, pkg)
            .apply()
    }

    fun resolvePalette(context: Context, albumArt: Bitmap?): ThemePalette {
        val mode = getThemeMode(context)
        val opacity = getOpacityPercent(context)
        val alpha = ((opacity / 100f) * 255f).toInt().coerceIn(38, 255)

        val baseSeedColor: Int = when (mode) {
            THEME_ALBUM_ART -> extractDominantVibrantColor(albumArt) ?: getSystemMaterialYouSeed(context)
            THEME_MATERIAL_YOU -> getSystemMaterialYouSeed(context)
            THEME_VIOLET -> Color.parseColor("#A855F7")
            THEME_EMERALD -> Color.parseColor("#10B981")
            THEME_ROSE -> Color.parseColor("#F43F5E")
            THEME_AMBER -> Color.parseColor("#F59E0B")
            THEME_CYAN -> Color.parseColor("#06B6D4")
            THEME_MONOCHROME -> Color.parseColor("#E5E7EB")
            else -> Color.parseColor("#8B5CF6")
        }

        val hsv = FloatArray(3)
        Color.colorToHSV(baseSeedColor, hsv)
        val hue = hsv[0]
        val isMono = (mode == THEME_MONOCHROME || hsv[1] < 0.08f)

        val surfaceRgb = if (isMono) {
            Color.HSVToColor(floatArrayOf(0f, 0f, 0.10f))
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.38f, 0.14f))
        }
        val cardSurface = Color.argb(
            alpha,
            Color.red(surfaceRgb),
            Color.green(surfaceRgb),
            Color.blue(surfaceRgb)
        )

        val accentRgb = if (isMono) {
            Color.HSVToColor(floatArrayOf(0f, 0f, 0.90f))
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.64f, 0.95f))
        }
        val accentColor = Color.argb(
            alpha,
            Color.red(accentRgb),
            Color.green(accentRgb),
            Color.blue(accentRgb)
        )

        val onAccentColor = Color.parseColor("#111318")

        val strokeRgb = if (isMono) {
            Color.WHITE
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.42f, 0.88f))
        }
        val strokeColor = Color.argb(
            (alpha * 0.48f).toInt().coerceIn(28, 120),
            Color.red(strokeRgb),
            Color.green(strokeRgb),
            Color.blue(strokeRgb)
        )

        val secondaryRgb = if (isMono) {
            Color.parseColor("#D1D5DB")
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.25f, 0.90f))
        }

        return ThemePalette(
            cardSurfaceColor = cardSurface,
            strokeColor = strokeColor,
            accentColor = accentColor,
            onAccentColor = onAccentColor,
            primaryTextColor = Color.parseColor("#F9FAFB"),
            secondaryTextColor = secondaryRgb,
            opacityAlpha = alpha
        )
    }

    private fun getSystemMaterialYouSeed(context: Context): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                return context.getColor(android.R.color.system_accent1_400)
            } catch (_: Throwable) {
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            try {
                val wm = WallpaperManager.getInstance(context)
                val colors: WallpaperColors? = wm.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                colors?.primaryColor?.toArgb()?.let { return it }
            } catch (_: Throwable) {
            }
        }
        return Color.parseColor("#8B5CF6")
    }

    private fun extractDominantVibrantColor(bitmap: Bitmap?): Int? {
        if (bitmap == null || bitmap.isRecycled) return null
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return null

        var bestColor: Int? = null
        var bestScore = -1f
        val hsv = FloatArray(3)

        val stepX = (w / 10).coerceAtLeast(1)
        val stepY = (h / 10).coerceAtLeast(1)

        var y = stepY / 2
        while (y < h) {
            var x = stepX / 2
            while (x < w) {
                val pixel = bitmap.getPixel(x, y)
                if (Color.alpha(pixel) > 150) {
                    Color.colorToHSV(pixel, hsv)
                    val sat = hsv[1]
                    val value = hsv[2]
                    val score = sat * 1.4f + (1f - kotlin.math.abs(value - 0.65f))
                    if (value in 0.18f..0.96f && sat >= 0.14f && score > bestScore) {
                        bestScore = score
                        bestColor = pixel
                    }
                }
                x += stepX
            }
            y += stepY
        }
        return bestColor
    }
}
