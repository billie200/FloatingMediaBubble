package com.example.floatingmediacontroller

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build

/**
 * Stores user customization (Opacity, Color Theme, Target Media App) and extracts
 * Material You / Album Art colors with zero external library overhead.
 */
object BubblePrefs {
    private const val PREFS_NAME = "floating_bubble_prefs"
    private const val KEY_OPACITY = "opacity_percent"       // 15..100 (default 78)
    private const val KEY_THEME_MODE = "theme_mode"         // 0=Album Art Auto, 1=Material You System, 2..7=Custom Presets
    private const val KEY_TARGET_PKG = "target_package"     // "" = Auto (Playing app), or specific packageName

    const val THEME_ALBUM_ART = 0
    const val THEME_MATERIAL_YOU = 1
    const val THEME_VIOLET = 2
    const val THEME_EMERALD = 3
    const val THEME_ROSE = 4
    const val THEME_AMBER = 5
    const val THEME_CYAN = 6
    const val THEME_MONOCHROME = 7

    data class ThemePalette(
        val cardSurfaceColor: Int,
        val strokeColor: Int,
        val accentColor: Int,
        val onAccentColor: Int,
        val primaryTextColor: Int
    )

    fun getOpacityPercent(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_OPACITY, 78)
            .coerceIn(15, 100)
    }

    fun setOpacityPercent(context: Context, percent: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_OPACITY, percent.coerceIn(15, 100))
            .apply()
    }

    fun getThemeMode(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_THEME_MODE, THEME_ALBUM_ART)
    }

    fun setThemeMode(context: Context, mode: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_THEME_MODE, mode)
            .apply()
    }

    fun getTargetPackage(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TARGET_PKG, "") ?: ""
    }

    fun setTargetPackage(context: Context, pkg: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TARGET_PKG, pkg)
            .apply()
    }

    /**
     * Resolves the Material 3 tonal dark palette based on user's chosen theme mode,
     * current album art, and opacity slider.
     */
    fun resolvePalette(context: Context, albumArt: Bitmap?): ThemePalette {
        val mode = getThemeMode(context)
        val opacity = getOpacityPercent(context)
        val alpha = ((opacity / 100f) * 255f).toInt().coerceIn(38, 255)

        val baseSeedColor: Int = when (mode) {
            THEME_ALBUM_ART -> extractDominantVibrantColor(albumArt) ?: getSystemMaterialYouSeed(context)
            THEME_MATERIAL_YOU -> getSystemMaterialYouSeed(context)
            THEME_VIOLET -> Color.parseColor("#A855F7")
            THEME_EMERALD -> Color.parseColor("#10B981")
            THEME_ROSE -> Color.parseColor("#F43F5E")
            THEME_AMBER -> Color.parseColor("#F59E0B")
            THEME_CYAN -> Color.parseColor("#06B6D4")
            THEME_MONOCHROME -> Color.parseColor("#E5E7EB")
            else -> Color.parseColor("#8B5CF6")
        }

        val hsv = FloatArray(3)
        Color.colorToHSV(baseSeedColor, hsv)
        val hue = hsv[0]
        val isMono = (mode == THEME_MONOCHROME || hsv[1] < 0.08f)

        // Material 3 Expressive Dark Surface (deep tonal tint matching hue)
        val surfaceRgb = if (isMono) {
            Color.HSVToColor(floatArrayOf(0f, 0f, 0.10f))
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.35f, 0.14f))
        }
        val cardSurface = Color.argb(
            alpha,
            Color.red(surfaceRgb),
            Color.green(surfaceRgb),
            Color.blue(surfaceRgb)
        )

        // Material 3 Accent Pill Color
        val accentRgb = if (isMono) {
            Color.HSVToColor(floatArrayOf(0f, 0f, 0.88f))
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.62f, 0.92f))
        }
        val accentColor = Color.argb(
            (alpha + 25).coerceAtMost(255),
            Color.red(accentRgb),
            Color.green(accentRgb),
            Color.blue(accentRgb)
        )

        val onAccentColor = if (isMono) Color.parseColor("#111318") else Color.parseColor("#111318")

        // Subtle glass stroke tinted with the accent hue
        val strokeRgb = if (isMono) {
            Color.WHITE
        } else {
            Color.HSVToColor(floatArrayOf(hue, 0.35f, 0.85f))
        }
        val strokeColor = Color.argb(
            68,
            Color.red(strokeRgb),
            Color.green(strokeRgb),
            Color.blue(strokeRgb)
        )

        return ThemePalette(
            cardSurfaceColor = cardSurface,
            strokeColor = strokeColor,
            accentColor = accentColor,
            onAccentColor = onAccentColor,
            primaryTextColor = Color.parseColor("#F9FAFB")
        )
    }

    private fun getSystemMaterialYouSeed(context: Context): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                // system_accent1_400 gives the user's Android 12-16 Material You dynamic wallpaper color
                return context.getColor(android.R.color.system_accent1_400)
            } catch (_: Throwable) {
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            try {
                val wm = WallpaperManager.getInstance(context)
                val colors: WallpaperColors? = wm.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                colors?.primaryColor?.toArgb()?.let { return it }
            } catch (_: Throwable) {
            }
        }
        return Color.parseColor("#8B5CF6")
    }

    /**
     * Fast, zero-allocation 8x8 sampling of the downscaled album art to find a rich accent color.
     */
    private fun extractDominantVibrantColor(bitmap: Bitmap?): Int? {
        if (bitmap == null || bitmap.isRecycled) return null
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return null

        var bestColor: Int? = null
        var bestScore = -1f
        val hsv = FloatArray(3)

        val stepX = (w / 8).coerceAtLeast(1)
        val stepY = (h / 8).coerceAtLeast(1)

        var y = stepY / 2
        while (y < h) {
            var x = stepX / 2
            while (x < w) {
                val pixel = bitmap.getPixel(x, y)
                if (Color.alpha(pixel) > 180) {
                    Color.colorToHSV(pixel, hsv)
                    val sat = hsv[1]
                    val value = hsv[2]
                    // Favor vibrant mid-to-bright colors over black/white/grey
                    val score = sat * 1.4f + (1f - kotlin.math.abs(value - 0.65f))
                    if (value in 0.18f..0.96f && sat >= 0.15f && score > bestScore) {
                        bestScore = score
                        bestColor = pixel
                    }
                }
                x += stepX
            }
            y += stepY
        }
        return bestColor
    }
}
