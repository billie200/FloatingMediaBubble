package com.example.floatingmediacontroller

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class FloatingWidgetService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_media_overlay_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_OVERLAY = "com.example.floatingmediacontroller.ACTION_STOP_OVERLAY"
        const val ACTION_REFRESH_STYLE = "com.example.floatingmediacontroller.ACTION_REFRESH_STYLE"

        // Fast Stage 1 hold (300ms) = Toggle Expand / Minimize
        private const val HOLD_EXPAND_MS = 300L
        // Stage 2 long-long hold (1350ms) = Close & Stop Bubble
        private const val HOLD_CLOSE_MS = 1350L
        // OLED Burn-in idle timeout (6 seconds without touch -> gently dims buttons/card)
        private const val IDLE_DIM_TIMEOUT_MS = 6000L
    }

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var sessionPickerView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    // Expanded View Elements
    private var expandedCard: LinearLayout? = null
    private var artFrameExpanded: FrameLayout? = null
    private var ivExpandedArt: ImageView? = null
    private var tvSessionSwitcherBadge: TextView? = null
    private var tvTrackTitle: TextView? = null
    private var tvArtistName: TextView? = null
    private var seekProgress: SeekBar? = null
    private var tvTimeNow: TextView? = null
    private var tvTimeRemaining: TextView? = null
    private var tvTimeTotal: TextView? = null
    private var expandedButtonsRow: LinearLayout? = null
    private var btnRewind5: ImageButton? = null
    private var btnPlayPauseExpanded: ImageButton? = null
    private var btnForward5: ImageButton? = null

    // Minimized View Elements (Cute Rounded-Square Mini Card with Album Art + Frosted Bottom Control Dock)
    private var miniCard: FrameLayout? = null
    private var ivMiniArtBg: ImageView? = null
    private var vMiniBorder: View? = null
    private var miniControlDock: LinearLayout? = null
    private var btnMiniRewind5: ImageButton? = null
    private var btnMiniPlayPause: ImageButton? = null
    private var btnMiniForward5: ImageButton? = null

    private var isMiniMode = false
    private var isUserSeeking = false
    private var isIdleDimmed = false
    private var pixelShiftStep = 0
    private var latestState = MediaSessionBridge.MediaUiState()
    private val mainHandler = Handler(Looper.getMainLooper())

    // 1-second ticker to update Now Time, Remaining Time, Full Time, and SeekBar in Expanded Mode
    private val progressTicker = object : Runnable {
        override fun run() {
            updateProgressUi()
            if (!isMiniMode && floatingView != null) {
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    // OLED Burn-in Protection: dims buttons & card after 6s of inactivity
    private val idleDimRunnable = Runnable {
        if (BubblePrefs.isBurnInProtectionEnabled(this)) {
            isIdleDimmed = true
            applyIdleVisualState()
        }
    }

    // OLED Burn-in Protection: subtle 2px orbital micro-shift every 30s so static button icons never burn in
    private val pixelShiftTicker = object : Runnable {
        override fun run() {
            if (floatingView != null && BubblePrefs.isBurnInProtectionEnabled(this@FloatingWidgetService)) {
                val offsets = arrayOf(
                    Pair(0, 0),
                    Pair(2, 1),
                    Pair(0, 2),
                    Pair(-2, 1),
                    Pair(-2, -1),
                    Pair(0, -2),
                    Pair(2, -1)
                )
                pixelShiftStep = (pixelShiftStep + 1) % offsets.size
                val (dx, dy) = offsets[pixelShiftStep]
                expandedButtonsRow?.translationX = dx.toFloat()
                expandedButtonsRow?.translationY = dy.toFloat()
                miniControlDock?.translationX = dx.toFloat()
                miniControlDock?.translationY = dy.toFloat()
            } else {
                expandedButtonsRow?.translationX = 0f
                expandedButtonsRow?.translationY = 0f
                miniControlDock?.translationX = 0f
                miniControlDock?.translationY = 0f
            }
            if (floatingView != null) {
                mainHandler.postDelayed(this, 30_000L)
            }
        }
    }

    private val mediaStateListener: (MediaSessionBridge.MediaUiState) -> Unit = { state ->
        latestState = state
        updateWidgetUi(state)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startOverlayForeground()
        ensureBubbleShown()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH_STYLE -> {
                ensureBubbleShown()
                wakeFromIdleDim()
                applyScaleDimensions()
                updateWidgetUi(latestState)
                return START_STICKY
            }
        }
        startOverlayForeground()
        ensureBubbleShown()
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
        mainHandler.postDelayed({ System.gc() }, 350L)
        return START_STICKY
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            System.gc()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(progressTicker)
        mainHandler.removeCallbacks(idleDimRunnable)
        mainHandler.removeCallbacks(pixelShiftTicker)
        MediaSessionBridge.unregisterListener(mediaStateListener)
        dismissSessionPickerPopup()
        removeFloatingView()
        super.onDestroy()
    }

    private fun ensureBubbleShown() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                applicationContext,
                getString(R.string.msg_enable_overlay_first),
                Toast.LENGTH_SHORT
            ).show()
            stopSelf()
            return
        }
        if (floatingView == null) {
            createFloatingView()
        }
        MediaSessionBridge.registerListener(mediaStateListener)
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
        restartProgressTicker()
        wakeFromIdleDim()
        mainHandler.removeCallbacks(pixelShiftTicker)
        mainHandler.postDelayed(pixelShiftTicker, 30_000L)
    }

    private fun restartProgressTicker() {
        mainHandler.removeCallbacks(progressTicker)
        if (!isMiniMode && floatingView != null) {
            mainHandler.post(progressTicker)
        }
    }

    private fun wakeFromIdleDim() {
        mainHandler.removeCallbacks(idleDimRunnable)
        if (isIdleDimmed) {
            isIdleDimmed = false
            applyIdleVisualState()
        }
        if (BubblePrefs.isBurnInProtectionEnabled(this)) {
            mainHandler.postDelayed(idleDimRunnable, IDLE_DIM_TIMEOUT_MS)
        }
    }

    /**
     * When idle in OLED Burn-in Protection mode, gently lowers button & card alpha so static bright pixels
     * never wear the OLED panel. Touching the widget anywhere immediately restores 100% user opacity.
     */
    private fun applyIdleVisualState() {
        val factor = if (isIdleDimmed && BubblePrefs.isBurnInProtectionEnabled(this)) 0.38f else 1.0f
        expandedButtonsRow?.alpha = factor
        miniControlDock?.alpha = factor
        tvSessionSwitcherBadge?.alpha = factor
        seekProgress?.alpha = factor
        val userAlpha = BubblePrefs.getOpacityPercent(this) / 100f
        val artAlpha = ((userAlpha * (if (isIdleDimmed) 0.55f else 1.0f)) * 255f).toInt().coerceIn(25, 255)
        ivExpandedArt?.imageAlpha = artAlpha
        ivMiniArtBg?.imageAlpha = artAlpha
    }

    private fun startOverlayForeground() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.notification_channel_desc)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }

            val stopIntent = Intent(this, FloatingWidgetService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            val stopPendingIntent = PendingIntent.getService(
                this,
                0,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val openAppIntent = Intent(this, MainActivity::class.java)
            val openAppPendingIntent = PendingIntent.getActivity(
                this,
                1,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
            }

            val action = Notification.Action.Builder(
                R.drawable.ic_close,
                getString(R.string.action_close_bubble),
                stopPendingIntent
            ).build()

            val notification = builder
                .setSmallIcon(R.drawable.ic_music_note)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notification_active_text))
                .setContentIntent(openAppPendingIntent)
                .addAction(action)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun createFloatingView() {
        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val inflater = LayoutInflater.from(this)
            val rootView = inflater.inflate(R.layout.layout_floating_widget, null)
            floatingView = rootView

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 36
                y = 240
            }

            expandedCard = rootView.findViewById(R.id.expandedCard)
            artFrameExpanded = rootView.findViewById(R.id.artFrameExpanded)
            ivExpandedArt = rootView.findViewById(R.id.ivExpandedArt)
            tvSessionSwitcherBadge = rootView.findViewById(R.id.tvSessionSwitcherBadge)
            tvTrackTitle = rootView.findViewById(R.id.tvTrackTitle)
            tvArtistName = rootView.findViewById(R.id.tvArtistName)
            seekProgress = rootView.findViewById(R.id.seekProgress)
            tvTimeNow = rootView.findViewById(R.id.tvTimeNow)
            tvTimeRemaining = rootView.findViewById(R.id.tvTimeRemaining)
            tvTimeTotal = rootView.findViewById(R.id.tvTimeTotal)
            expandedButtonsRow = rootView.findViewById(R.id.expandedButtonsRow)
            btnRewind5 = rootView.findViewById(R.id.btnRewind5)
            btnPlayPauseExpanded = rootView.findViewById(R.id.btnPlayPauseExpanded)
            btnForward5 = rootView.findViewById(R.id.btnForward5)

            miniCard = rootView.findViewById(R.id.miniCard)
            ivMiniArtBg = rootView.findViewById(R.id.ivMiniArtBg)
            vMiniBorder = rootView.findViewById(R.id.vMiniBorder)
            miniControlDock = rootView.findViewById(R.id.miniControlDock)
            btnMiniRewind5 = rootView.findViewById(R.id.btnMiniRewind5)
            btnMiniPlayPause = rootView.findViewById(R.id.btnMiniPlayPause)
            btnMiniForward5 = rootView.findViewById(R.id.btnMiniForward5)

            tvTrackTitle?.isSelected = true
            tvArtistName?.isSelected = true

            // Action to open the currently playing music app (Spotify, YouTube Music, etc.)
            val openPlayingAppAction: () -> Unit = {
                triggerStrongHaptic(isDoublePulse = false)
                val opened = MediaSessionBridge.openCurrentMediaApp(this)
                if (!opened) {
                    val intent = Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                }
            }

            // 1. Expanded Album Art:
            //    - Single Click: Opens the currently playing app (Spotify, YouTube Music, etc.)!
            //    - Hold (300ms): Minimize to Rounded-Square Mini Mode
            //    - Long-Long Hold (1350ms): Close & Stop Bubble
            ivExpandedArt?.let { art ->
                attachTwoStageHoldAndDragHandler(
                    targetView = art,
                    onTap = openPlayingAppAction,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 2. Top-Right Badge ("⇄ AppName"):
            //    - Single Click: Opens the Floating Sessions + Size/Opacity/Colors window!
            tvSessionSwitcherBadge?.let { badge ->
                attachTwoStageHoldAndDragHandler(
                    targetView = badge,
                    onTap = {
                        triggerStrongHaptic(isDoublePulse = false)
                        showFloatingSessionPickerDialog()
                    },
                    onStage1Hold = { showFloatingSessionPickerDialog() },
                    onStage2Hold = null
                )
            }

            // 3. Title & Artist Text:
            //    - Single Click: Opens the playing app
            //    - Hold (300ms): Minimize to Mini Mode
            tvTrackTitle?.let { tv ->
                attachTwoStageHoldAndDragHandler(
                    targetView = tv,
                    onTap = openPlayingAppAction,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            tvArtistName?.let { tv ->
                attachTwoStageHoldAndDragHandler(
                    targetView = tv,
                    onTap = openPlayingAppAction,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 4. Adaptive Interactive SeekBar
            seekProgress?.max = 1000
            seekProgress?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        wakeFromIdleDim()
                        if (latestState.durationMs > 0L) {
                            val targetMs = (latestState.durationMs * progress) / 1000L
                            val remMs = (latestState.durationMs - targetMs).coerceAtLeast(0L)
                            tvTimeNow?.text = formatTimeMs(targetMs)
                            tvTimeRemaining?.text = "-${formatTimeMs(remMs)}"
                        }
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = true
                    wakeFromIdleDim()
                }

                override fun onStopTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = false
                    wakeFromIdleDim()
                    val progress = sb?.progress ?: 0
                    if (latestState.durationMs > 0L) {
                        val targetMs = (latestState.durationMs * progress) / 1000L
                        MediaSessionBridge.seekToPositionMs(targetMs, this@FloatingWidgetService)
                    }
                }
            })

            // 5. Expanded Play/Pause Button:
            //    - Single Click: Play / Pause
            //    - Hold (300ms): Minimize to Rounded-Square Mini Mode
            //    - Long-Long Hold (1350ms): Close & Stop Bubble
            btnPlayPauseExpanded?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 6. Expanded -5s / +5s Buttons (Tap: ±5s, Hold 300ms: Previous / Next Track)
            btnRewind5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(-5_000L, this) },
                    onStage1Hold = { MediaSessionBridge.skipPreviousTrack(this) },
                    onStage2Hold = null
                )
            }
            btnForward5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(5_000L, this) },
                    onStage1Hold = { MediaSessionBridge.skipNextTrack(this) },
                    onStage2Hold = null
                )
            }

            // 7. Minimized Rounded-Square Card:
            //    - Top Album Art area: Tap = Open Playing App! | Hold (300ms) = Expand to Full Card! | Long-Long Hold (1350ms) = Close!
            //    - Bottom Frosted Dock:
            //      - Center Play/Pause: Tap = Play/Pause | Hold (300ms) = Expand to Full Card! | Long-Long Hold (1350ms) = Close!
            //      - Left -5s: Tap = -5s | Hold (300ms) = Previous Track
            //      - Right +5s: Tap = +5s | Hold (300ms) = Next Track
            ivMiniArtBg?.let { artBg ->
                attachTwoStageHoldAndDragHandler(
                    targetView = artBg,
                    onTap = openPlayingAppAction,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            vMiniBorder?.let { border ->
                attachTwoStageHoldAndDragHandler(
                    targetView = border,
                    onTap = openPlayingAppAction,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            btnMiniPlayPause?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            btnMiniRewind5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(-5_000L, this) },
                    onStage1Hold = { MediaSessionBridge.skipPreviousTrack(this) },
                    onStage2Hold = null
                )
            }
            btnMiniForward5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(5_000L, this) },
                    onStage1Hold = { MediaSessionBridge.skipNextTrack(this) },
                    onStage2Hold = null
                )
            }

            // 8. Dragging from card background
            expandedCard?.let { card ->
                attachTwoStageHoldAndDragHandler(
                    targetView = card,
                    onTap = null,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            applyScaleDimensions()
            windowManager?.addView(rootView, layoutParams)
            updateWidgetUi(latestState)
            restartProgressTicker()
        } catch (t: Throwable) {
            Toast.makeText(
                applicationContext,
                "Overlay error: ${t.javaClass.simpleName}: ${t.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /**
     * Dynamically scales all dimensions of both Expanded and Minimized views based on the user's
     * chosen Size Scale (70% to 145%) so the bubble is never stuck at one fixed size!
     */
    private fun applyScaleDimensions() {
        val density = resources.displayMetrics.density
        val scale = BubblePrefs.getScalePercent(this) / 100f

        fun dp(value: Float): Int = (value * scale * density).toInt().coerceAtLeast(1)

        // Scale Expanded Card
        expandedCard?.let { card ->
            val lp = card.layoutParams
            lp.width = dp(164f)
            card.layoutParams = lp
            val p = dp(10f)
            card.setPadding(p, p, p, p)
        }
        artFrameExpanded?.let { frame ->
            val lp = frame.layoutParams
            lp.width = dp(140f)
            lp.height = dp(140f)
            frame.layoutParams = lp
        }
        tvTrackTitle?.textSize = 12.5f * scale.coerceIn(0.85f, 1.25f)
        tvArtistName?.textSize = 11f * scale.coerceIn(0.85f, 1.25f)

        expandedButtonsRow?.let { row ->
            val lp = row.layoutParams
            lp.height = dp(40f)
            row.layoutParams = lp
        }
        btnRewind5?.let { btn ->
            val lp = btn.layoutParams
            lp.width = dp(38f)
            lp.height = dp(38f)
            btn.layoutParams = lp
        }
        btnPlayPauseExpanded?.let { btn ->
            val lp = btn.layoutParams
            lp.width = dp(48f)
            lp.height = dp(38f)
            btn.layoutParams = lp
        }
        btnForward5?.let { btn ->
            val lp = btn.layoutParams
            lp.width = dp(38f)
            lp.height = dp(38f)
            btn.layoutParams = lp
        }

        // Scale Cute Minimized Rounded-Square Card
        miniCard?.let { mini ->
            val lp = mini.layoutParams
            lp.width = dp(98f)
            lp.height = dp(98f)
            mini.layoutParams = lp
            val p = dp(4f)
            mini.setPadding(p, p, p, p)
        }
        miniControlDock?.let { dock ->
            val lp = dock.layoutParams as? FrameLayout.LayoutParams
            if (lp != null) {
                lp.height = dp(34f)
                val m = dp(4f)
                lp.setMargins(m, m, m, m)
                dock.layoutParams = lp
            }
        }
        btnMiniRewind5?.let { btn ->
            val lp = btn.layoutParams
            lp.width = dp(26f)
            lp.height = dp(28f)
            btn.layoutParams = lp
        }
        btnMiniPlayPause?.let { btn ->
            val lp = btn.layoutParams
            lp.width = dp(30f)
            lp.height = dp(28f)
            btn.layoutParams = lp
        }
        btnMiniForward5?.let { btn ->
            val lp = btn.layoutParams
            lp.width = dp(26f)
            lp.height = dp(28f)
            btn.layoutParams = lp
        }

        floatingView?.let { view ->
            try {
                windowManager?.updateViewLayout(view, layoutParams)
            } catch (_: Throwable) {
            }
        }
    }

    private fun toggleMiniMode() {
        isMiniMode = !isMiniMode
        expandedCard?.visibility = if (isMiniMode) View.GONE else View.VISIBLE
        miniCard?.visibility = if (isMiniMode) View.VISIBLE else View.GONE
        restartProgressTicker()
        wakeFromIdleDim()
        floatingView?.let { view ->
            try {
                windowManager?.updateViewLayout(view, layoutParams)
            } catch (_: Throwable) {
            }
        }
    }

    private fun closeBubbleWithFeedback() {
        triggerStrongHaptic(isDoublePulse = true)
        Toast.makeText(
            applicationContext,
            getString(R.string.toast_bubble_closed),
            Toast.LENGTH_SHORT
        ).show()
        stopSelf()
    }

    /**
     * Floating Control Center Dialog (opened by tapping the top-right "⇄ AppName" badge on the Album Art):
     * - Switch active Media Session (Auto or specific playing app)
     * - Adjust Bubble Size slider (70% – 145%) live!
     * - Adjust Opacity slider (15% – 100%) live!
     * - Toggle OLED Burn-in Protection!
     */
    private fun showFloatingSessionPickerDialog() {
        dismissSessionPickerPopup()
        try {
            val wm = windowManager ?: return
            val density = resources.displayMetrics.density
            val palette = BubblePrefs.resolvePalette(this, latestState.squareArt)

            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val pad = (16 * density).toInt()
                setPadding(pad, pad, pad, pad)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 24f * density
                    setColor(Color.argb(245, 16, 18, 26))
                    setStroke((1.6f * density).toInt().coerceAtLeast(1), palette.accentColor)
                }
            }

            val titleTv = TextView(this).apply {
                text = "Sessions & Quick Controls"
                setTextColor(Color.WHITE)
                textSize = 15f
                paint.isFakeBoldText = true
            }
            container.addView(titleTv)

            val sessions = MediaSessionBridge.getAvailableSessionsSnapshot(this)
            val currentTarget = BubblePrefs.getTargetPackage(this)

            fun addOptionButton(label: String, isSelected: Boolean, onClick: () -> Unit) {
                val btn = Button(this).apply {
                    text = if (isSelected) "✓  $label" else "    $label"
                    isAllCaps = false
                    textSize = 12.5f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER_VERTICAL or Gravity.START
                    val hPad = (12 * density).toInt()
                    setPadding(hPad, 0, hPad, 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 12f * density
                        if (isSelected) {
                            setColor(Color.argb(95, Color.red(palette.accentColor), Color.green(palette.accentColor), Color.blue(palette.accentColor)))
                            setStroke((1.5f * density).toInt().coerceAtLeast(1), palette.accentColor)
                        } else {
                            setColor(Color.argb(38, 255, 255, 255))
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        (244 * density).toInt(),
                        (38 * density).toInt()
                    ).apply {
                        topMargin = (5 * density).toInt()
                    }
                    setOnClickListener {
                        triggerStrongHaptic(isDoublePulse = false)
                        onClick()
                        dismissSessionPickerPopup()
                    }
                }
                container.addView(btn)
            }

            addOptionButton("Auto (Follow playing app)", currentTarget.isBlank()) {
                BubblePrefs.setTargetPackage(this, "")
                MediaSessionBridge.forceRefreshUi(this)
            }

            sessions.forEach { entry ->
                val stateIcon = if (entry.isPlaying) "▶" else "⏸"
                val display = "${entry.appLabel} ($stateIcon ${entry.title.take(18)})"
                addOptionButton(display, currentTarget == entry.packageName) {
                    BubblePrefs.setTargetPackage(this, entry.packageName)
                    MediaSessionBridge.forceRefreshUi(this)
                }
            }

            // Live Size Slider right inside the popup!
            val currentScale = BubblePrefs.getScalePercent(this)
            val tvSizeLabel = TextView(this).apply {
                text = "Widget Size: $currentScale%"
                setTextColor(Color.parseColor("#E5E7EB"))
                textSize = 12f
                setPadding(0, (10 * density).toInt(), 0, (2 * density).toInt())
            }
            container.addView(tvSizeLabel)

            val sbSize = SeekBar(this).apply {
                max = 75 // 70%..145%
                progress = (currentScale - 70).coerceIn(0, 75)
                thumbTintList = ColorStateList.valueOf(palette.accentColor)
                progressTintList = ColorStateList.valueOf(palette.accentColor)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        val pct = (p + 70).coerceIn(70, 145)
                        tvSizeLabel.text = "Widget Size: $pct%"
                        BubblePrefs.setScalePercent(this@FloatingWidgetService, pct)
                        applyScaleDimensions()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            container.addView(sbSize)

            // Live Opacity Slider right inside the popup!
            val currentOpacity = BubblePrefs.getOpacityPercent(this)
            val tvOpacityLabel = TextView(this).apply {
                text = "Opacity: $currentOpacity%"
                setTextColor(Color.parseColor("#E5E7EB"))
                textSize = 12f
                setPadding(0, (6 * density).toInt(), 0, (2 * density).toInt())
            }
            container.addView(tvOpacityLabel)

            val sbOpacity = SeekBar(this).apply {
                max = 85 // 15%..100%
                progress = (currentOpacity - 15).coerceIn(0, 85)
                thumbTintList = ColorStateList.valueOf(palette.accentColor)
                progressTintList = ColorStateList.valueOf(palette.accentColor)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        val pct = (p + 15).coerceIn(15, 100)
                        tvOpacityLabel.text = "Opacity: $pct%"
                        BubblePrefs.setOpacityPercent(this@FloatingWidgetService, pct)
                        updateWidgetUi(latestState)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            container.addView(sbOpacity)

            // OLED Burn-in Protection checkbox
            val cbBurnIn = CheckBox(this).apply {
                text = "OLED Burn-in Protection (Idle Dim + Shift)"
                setTextColor(Color.parseColor("#D1D5DB"))
                textSize = 11.5f
                isChecked = BubblePrefs.isBurnInProtectionEnabled(this@FloatingWidgetService)
                buttonTintList = ColorStateList.valueOf(palette.accentColor)
                setOnCheckedChangeListener { _, checked ->
                    BubblePrefs.setBurnInProtectionEnabled(this@FloatingWidgetService, checked)
                    wakeFromIdleDim()
                }
            }
            container.addView(cbBurnIn)

            // Bottom Actions Row
            val actionsRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = (10 * density).toInt()
                }
            }

            fun makeActionPill(label: String, textColor: Int, onClick: () -> Unit): Button {
                return Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = 11.5f
                    setTextColor(textColor)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 10f * density
                        setColor(Color.argb(45, 255, 255, 255))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        0,
                        (36 * density).toInt(),
                        1f
                    ).apply {
                        marginEnd = (4 * density).toInt()
                        marginStart = (4 * density).toInt()
                    }
                    setOnClickListener {
                        onClick()
                        dismissSessionPickerPopup()
                    }
                }
            }

            actionsRow.addView(makeActionPill("Colors ⚙", Color.parseColor("#E5E7EB")) {
                val i = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(i)
            })
            actionsRow.addView(makeActionPill("Done", Color.parseColor("#A7F3D0")) {
                // Closes popup
            })
            container.addView(actionsRow)

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            val popupParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            container.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    dismissSessionPickerPopup()
                    true
                } else {
                    false
                }
            }

            sessionPickerView = container
            wm.addView(container, popupParams)
        } catch (_: Throwable) {
        }
    }

    private fun dismissSessionPickerPopup() {
        sessionPickerView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Throwable) {
            }
        }
        sessionPickerView = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTwoStageHoldAndDragHandler(
        targetView: View,
        onTap: (() -> Unit)?,
        onStage1Hold: (() -> Unit)?,
        onStage2Hold: (() -> Unit)?
    ) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var stage1Reached = false
        var stage2Triggered = false

        val stage1Runnable = Runnable {
            if (!isDragging && onStage1Hold != null) {
                stage1Reached = true
                targetView.performHapticFeedback(
                    HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                )
                triggerStrongHaptic(isDoublePulse = false)
                if (onStage2Hold == null) {
                    onStage1Hold.invoke()
                }
            }
        }

        val stage2Runnable = Runnable {
            if (!isDragging && onStage2Hold != null) {
                stage2Triggered = true
                targetView.performHapticFeedback(
                    HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                )
                onStage2Hold.invoke()
            }
        }

        targetView.setOnTouchListener { v, event ->
            wakeFromIdleDim()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    stage1Reached = false
                    stage2Triggered = false

                    if (onStage1Hold != null) {
                        mainHandler.postDelayed(stage1Runnable, HOLD_EXPAND_MS)
                    }
                    if (onStage2Hold != null) {
                        mainHandler.postDelayed(stage2Runnable, HOLD_CLOSE_MS)
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                        v.isPressed = false
                        mainHandler.removeCallbacks(stage1Runnable)
                        mainHandler.removeCallbacks(stage2Runnable)
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        floatingView?.let { view ->
                            try {
                                windowManager?.updateViewLayout(view, layoutParams)
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(stage1Runnable)
                    mainHandler.removeCallbacks(stage2Runnable)
                    if (!isDragging && !stage2Triggered) {
                        if (stage1Reached) {
                            if (onStage2Hold != null) {
                                onStage1Hold?.invoke()
                            }
                        } else {
                            onTap?.invoke()
                        }
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(stage1Runnable)
                    mainHandler.removeCallbacks(stage2Runnable)
                    true
                }

                else -> false
            }
        }
    }

    private fun updateWidgetUi(state: MediaSessionBridge.MediaUiState) {
        val density = resources.displayMetrics.density
        val scale = BubblePrefs.getScalePercent(this) / 100f
        val palette = BubblePrefs.resolvePalette(this, state.squareArt)

        // 1. Expanded Card Material 3 Tonal Background
        val cardBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 26f * scale * density
            setColor(palette.cardSurfaceColor)
            setStroke((1.3f * density).toInt().coerceAtLeast(1), palette.strokeColor)
        }
        expandedCard?.background = cardBg

        // 2. Top-Right Badge ("⇄ AppName") to open Sessions & Quick Size/Opacity Menu
        val badgeLabel = if (state.appLabel.isNotBlank() && state.hasActiveSession) {
            "⇄ ${state.appLabel}"
        } else {
            "⇄ Sessions"
        }
        tvSessionSwitcherBadge?.text = badgeLabel
        tvSessionSwitcherBadge?.setTextColor(palette.onAccentColor)
        tvSessionSwitcherBadge?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 10f * density
            setColor(palette.accentColor)
        }

        // 3. Adaptive SeekBar Colors (Thumb, Progress Track, and Unplayed Track all match Material 3 palette!)
        seekProgress?.thumbTintList = ColorStateList.valueOf(palette.accentColor)
        seekProgress?.progressTintList = ColorStateList.valueOf(palette.accentColor)
        seekProgress?.progressBackgroundTintList = ColorStateList.valueOf(
            Color.argb(
                85,
                Color.red(palette.secondaryTextColor),
                Color.green(palette.secondaryTextColor),
                Color.blue(palette.secondaryTextColor)
            )
        )
        tvTimeNow?.setTextColor(palette.secondaryTextColor)
        tvTimeTotal?.setTextColor(palette.secondaryTextColor)

        // 4. Expanded Play/Pause Squircle Button
        val playBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 15f * scale * density
            setColor(palette.accentColor)
        }
        btnPlayPauseExpanded?.background = playBtnBg
        btnPlayPauseExpanded?.setColorFilter(palette.onAccentColor)

        // 5. Cute Rounded-Square Minimized Card + Frosted Bottom Dock
        val miniBorderDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 20f * scale * density
            setColor(
                if (state.squareArt != null) {
                    Color.TRANSPARENT
                } else {
                    palette.cardSurfaceColor
                }
            )
            setStroke((1.8f * density).toInt().coerceAtLeast(1), palette.strokeColor)
        }
        vMiniBorder?.background = miniBorderDrawable

        val dockAlpha = (palette.opacityAlpha * 0.88f).toInt().coerceIn(75, 235)
        val miniDockDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 14f * scale * density
            setColor(
                Color.argb(
                    dockAlpha,
                    Color.red(palette.cardSurfaceColor),
                    Color.green(palette.cardSurfaceColor),
                    Color.blue(palette.cardSurfaceColor)
                )
            )
            setStroke((1f * density).toInt().coerceAtLeast(1), palette.strokeColor)
        }
        miniControlDock?.background = miniDockDrawable

        val miniPlayBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 10f * scale * density
            setColor(palette.accentColor)
        }
        btnMiniPlayPause?.background = miniPlayBg
        btnMiniPlayPause?.setColorFilter(palette.onAccentColor)

        // 6. Separate Track Title and Artist Name
        if (tvTrackTitle?.text?.toString() != state.title) {
            tvTrackTitle?.text = state.title
            tvTrackTitle?.isSelected = true
        }
        tvTrackTitle?.setTextColor(palette.primaryTextColor)

        if (tvArtistName?.text?.toString() != state.artist) {
            tvArtistName?.text = state.artist
            tvArtistName?.isSelected = true
        }
        tvArtistName?.setTextColor(palette.secondaryTextColor)

        // 7. Play/Pause Icons
        val playIconRes = if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        btnPlayPauseExpanded?.setImageResource(playIconRes)
        btnMiniPlayPause?.setImageResource(playIconRes)

        // 8. Apply Rounded-Square Album Art & Opacity to both Expanded & Minimized views
        if (state.squareArt != null) {
            ivExpandedArt?.scaleType = ImageView.ScaleType.FIT_XY
            ivExpandedArt?.setImageBitmap(state.squareArt)
            ivExpandedArt?.clearColorFilter()

            ivMiniArtBg?.scaleType = ImageView.ScaleType.FIT_XY
            ivMiniArtBg?.setImageBitmap(state.squareArt)
            ivMiniArtBg?.clearColorFilter()
        } else {
            ivExpandedArt?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivExpandedArt?.setImageResource(R.drawable.ic_music_note)
            ivExpandedArt?.setColorFilter(palette.accentColor)

            ivMiniArtBg?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivMiniArtBg?.setImageResource(R.drawable.ic_music_note)
            ivMiniArtBg?.setColorFilter(palette.accentColor)
        }

        applyIdleVisualState()
        updateProgressUi()
    }

    private fun updateProgressUi() {
        if (isUserSeeking) return
        val duration = latestState.durationMs
        val current = MediaSessionBridge.getCurrentPositionMs()
        if (duration > 0L) {
            val remaining = (duration - current).coerceAtLeast(0L)
            tvTimeNow?.text = formatTimeMs(current)
            tvTimeRemaining?.text = "-${formatTimeMs(remaining)}"
            tvTimeTotal?.text = formatTimeMs(duration)
            val progressPermille = ((current * 1000L) / duration).toInt().coerceIn(0, 1000)
            seekProgress?.progress = progressPermille
            seekProgress?.isEnabled = true
        } else {
            tvTimeNow?.text = formatTimeMs(current)
            tvTimeRemaining?.text = "-0:00"
            tvTimeTotal?.text = "0:00"
            seekProgress?.progress = 0
            seekProgress?.isEnabled = false
        }
    }

    private fun formatTimeMs(ms: Long): String {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, seconds)
        }
    }

    private fun triggerStrongHaptic(isDoublePulse: Boolean) {
        try {
            val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator == null || !vibrator.hasVibrator()) return

            val effect = if (isDoublePulse) {
                VibrationEffect.createWaveform(
                    longArrayOf(0L, 95L, 65L, 130L),
                    intArrayOf(0, 255, 0, 255),
                    -1
                )
            } else {
                VibrationEffect.createOneShot(85L, 255)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val attrs = VibrationAttributes.Builder()
                    .setUsage(VibrationAttributes.USAGE_ALARM)
                    .build()
                vibrator.vibrate(effect, attrs)
            } else {
                @Suppress("DEPRECATION")
                val audioAttrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                @Suppress("DEPRECATION")
                vibrator.vibrate(effect, audioAttrs)
            }
        } catch (_: Throwable) {
        }
    }

    private fun removeFloatingView() {
        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Throwable) {
            }
        }
        floatingView = null
    }
}
