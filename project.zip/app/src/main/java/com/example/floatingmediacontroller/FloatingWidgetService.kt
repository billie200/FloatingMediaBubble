package com.example.floatingmediacontroller

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Outline
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatingWidgetService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_media_overlay_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_OVERLAY = "com.example.floatingmediacontroller.ACTION_STOP_OVERLAY"
    }

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    private var albumArtView: ImageView? = null
    private var titleTextView: TextView? = null
    private var textContainer: View? = null
    private var rewind5Button: ImageButton? = null
    private var playPauseButton: ImageButton? = null
    private var forward5Button: ImageButton? = null

    private var isCompactMode = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val mediaStateListener: (MediaSessionBridge.MediaUiState) -> Unit = { state ->
        updateWidgetUi(state)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startOverlayForeground()
        ensureBubbleShown()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_OVERLAY) {
            stopSelf()
            return START_NOT_STICKY
        }
        startOverlayForeground()
        ensureBubbleShown()
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
        return START_STICKY
    }

    override fun onDestroy() {
        MediaSessionBridge.unregisterListener(mediaStateListener)
        removeFloatingView()
        super.onDestroy()
    }

    private fun ensureBubbleShown() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                applicationContext,
                getString(R.string.msg_enable_overlay_first),
                Toast.LENGTH_SHORT
            ).show()
            stopSelf()
            return
        }
        if (floatingView == null) {
            createFloatingView()
        }
        MediaSessionBridge.registerListener(mediaStateListener)
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
    }

    private fun startOverlayForeground() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.notification_channel_desc)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }

            val stopIntent = Intent(this, FloatingWidgetService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            val stopPendingIntent = PendingIntent.getService(
                this,
                0,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val openAppIntent = Intent(this, MainActivity::class.java)
            val openAppPendingIntent = PendingIntent.getActivity(
                this,
                1,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_music_note)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notification_active_text))
                .setContentIntent(openAppPendingIntent)
                .addAction(
                    R.drawable.ic_close,
                    getString(R.string.action_close_bubble),
                    stopPendingIntent
                )
                .setOngoing(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun createFloatingView() {
        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

            // Wrap Service context with our Material 3 theme so inflation never crashes!
            val themedContext = ContextThemeWrapper(this, R.style.Theme_FloatingMediaController)
            val inflater = LayoutInflater.from(themedContext)
            val rootView = inflater.inflate(R.layout.layout_floating_widget, null)
            floatingView = rootView

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 40
                y = 280
            }

            albumArtView = rootView.findViewById(R.id.ivAlbumArt)
            titleTextView = rootView.findViewById(R.id.tvTrackTitle)
            textContainer = rootView.findViewById(R.id.textContainer)
            rewind5Button = rootView.findViewById(R.id.btnRewind5)
            playPauseButton = rootView.findViewById(R.id.btnPlayPause)
            forward5Button = rootView.findViewById(R.id.btnForward5)

            // Clip albumArtView into a perfect circle with zero Material dependency
            albumArtView?.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            albumArtView?.clipToOutline = true

            // Enable marquee scrolling on title
            titleTextView?.isSelected = true

            // Album Art: Tap = Compact Mini Mode, Long Press = Close Bubble, Drag = Move
            albumArtView?.let { artView ->
                attachDragAndGestureHandler(
                    targetView = artView,
                    onClick = { toggleCompactMode() },
                    onLongPress = {
                        triggerShortHaptic()
                        Toast.makeText(
                            applicationContext,
                            getString(R.string.toast_bubble_closed),
                            Toast.LENGTH_SHORT
                        ).show()
                        stopSelf()
                    }
                )
            }

            // Allow dragging from the pill root and title area too
            attachDragAndGestureHandler(
                targetView = rootView,
                onClick = null,
                onLongPress = null
            )
            textContainer?.let { container ->
                attachDragAndGestureHandler(
                    targetView = container,
                    onClick = { toggleCompactMode() },
                    onLongPress = null
                )
            }

            // -5s button (Tap: -5 seconds, Long press: Previous Track, Drag: Moves bubble)
            rewind5Button?.let { btn ->
                attachDragAndGestureHandler(
                    targetView = btn,
                    onClick = {
                        MediaSessionBridge.seekByMilliseconds(-5_000L, this)
                    },
                    onLongPress = {
                        triggerShortHaptic()
                        MediaSessionBridge.skipPreviousTrack(this)
                    }
                )
            }

            // Play / Pause button (Tap: Play/Pause, Drag: Moves bubble)
            playPauseButton?.let { btn ->
                attachDragAndGestureHandler(
                    targetView = btn,
                    onClick = {
                        MediaSessionBridge.togglePlayPause(this)
                    },
                    onLongPress = null
                )
            }

            // +5s button (Tap: +5 seconds, Long press: Next Track, Drag: Moves bubble)
            forward5Button?.let { btn ->
                attachDragAndGestureHandler(
                    targetView = btn,
                    onClick = {
                        MediaSessionBridge.seekByMilliseconds(5_000L, this)
                    },
                    onLongPress = {
                        triggerShortHaptic()
                        MediaSessionBridge.skipNextTrack(this)
                    }
                )
            }

            windowManager?.addView(rootView, layoutParams)
        } catch (t: Throwable) {
            Toast.makeText(
                applicationContext,
                "Overlay error: ${t.javaClass.simpleName}: ${t.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun toggleCompactMode() {
        isCompactMode = !isCompactMode
        textContainer?.visibility = if (isCompactMode) View.GONE else View.VISIBLE
        floatingView?.let { view ->
            try {
                windowManager?.updateViewLayout(view, layoutParams)
            } catch (_: Throwable) {
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDragAndGestureHandler(
        targetView: View,
        onClick: (() -> Unit)?,
        onLongPress: (() -> Unit)?
    ) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        val longPressTimeout = ViewConfiguration.getLongPressTimeout().toLong()

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging && onLongPress != null) {
                longPressTriggered = true
                onLongPress.invoke()
            }
        }

        targetView.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    if (onLongPress != null) {
                        mainHandler.postDelayed(longPressRunnable, longPressTimeout)
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                        v.isPressed = false
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        floatingView?.let { view ->
                            try {
                                windowManager?.updateViewLayout(view, layoutParams)
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!isDragging && !longPressTriggered) {
                        onClick?.invoke()
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(longPressRunnable)
                    true
                }

                else -> false
            }
        }
    }

    private fun updateWidgetUi(state: MediaSessionBridge.MediaUiState) {
        val displayTitle = if (state.artist.isNotBlank() && state.hasActiveSession) {
            "${state.title} • ${state.artist}"
        } else {
            state.title
        }
        if (titleTextView?.text?.toString() != displayTitle) {
            titleTextView?.text = displayTitle
            titleTextView?.isSelected = true
        }

        playPauseButton?.setImageResource(
            if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )

        if (state.albumArt != null) {
            albumArtView?.scaleType = ImageView.ScaleType.CENTER_CROP
            albumArtView?.setImageBitmap(state.albumArt)
            albumArtView?.imageTintList = null
        } else {
            albumArtView?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            albumArtView?.setImageResource(R.drawable.ic_music_note)
        }
    }

    private fun triggerShortHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager =
                    getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun removeFloatingView() {
        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Throwable) {
            }
        }
        floatingView = null
    }
}
