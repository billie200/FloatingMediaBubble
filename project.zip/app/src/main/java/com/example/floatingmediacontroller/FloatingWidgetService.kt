package com.example.floatingmediacontroller

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class FloatingWidgetService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_media_overlay_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_OVERLAY = "com.example.floatingmediacontroller.ACTION_STOP_OVERLAY"
        const val ACTION_REFRESH_STYLE = "com.example.floatingmediacontroller.ACTION_REFRESH_STYLE"

        // Faster Stage 1 hold (320ms) = Toggle Expand / Minimize
        private const val HOLD_EXPAND_MS = 320L
        // Stage 2 long-long hold (1350ms) = Close & Stop Bubble
        private const val HOLD_CLOSE_MS = 1350L
        // Double-tap window on Album Art (280ms)
        private const val DOUBLE_TAP_WINDOW_MS = 280L
    }

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var sessionPickerView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    // Expanded View Elements
    private var expandedCard: LinearLayout? = null
    private var ivExpandedArt: ImageView? = null
    private var tvOpenAppBadge: TextView? = null
    private var tvTrackTitle: TextView? = null
    private var tvArtistName: TextView? = null
    private var seekProgress: SeekBar? = null
    private var tvTimeNow: TextView? = null
    private var tvTimeRemaining: TextView? = null
    private var tvTimeTotal: TextView? = null
    private var btnRewind5: ImageButton? = null
    private var btnPlayPauseExpanded: ImageButton? = null
    private var btnForward5: ImageButton? = null

    // Minimized View Elements (Circular Album Art bg + -5s / Play-Pause / +5s)
    private var miniCard: FrameLayout? = null
    private var ivMiniArtBg: ImageView? = null
    private var vMiniScrim: View? = null
    private var btnMiniRewind5: ImageButton? = null
    private var btnMiniPlayPause: ImageButton? = null
    private var btnMiniForward5: ImageButton? = null

    private var isMiniMode = false
    private var isUserSeeking = false
    private var latestState = MediaSessionBridge.MediaUiState()
    private val mainHandler = Handler(Looper.getMainLooper())

    // 1-second ticker to update Now Time, Remaining Time, Full Time, and SeekBar in Expanded Mode
    private val progressTicker = object : Runnable {
        override fun run() {
            updateProgressUi()
            if (!isMiniMode && floatingView != null) {
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    private val mediaStateListener: (MediaSessionBridge.MediaUiState) -> Unit = { state ->
        latestState = state
        updateWidgetUi(state)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startOverlayForeground()
        ensureBubbleShown()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH_STYLE -> {
                ensureBubbleShown()
                updateWidgetUi(latestState)
                return START_STICKY
            }
        }
        startOverlayForeground()
        ensureBubbleShown()
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
        mainHandler.postDelayed({ System.gc() }, 350L)
        return START_STICKY
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            System.gc()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(progressTicker)
        MediaSessionBridge.unregisterListener(mediaStateListener)
        dismissSessionPickerPopup()
        removeFloatingView()
        super.onDestroy()
    }

    private fun ensureBubbleShown() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                applicationContext,
                getString(R.string.msg_enable_overlay_first),
                Toast.LENGTH_SHORT
            ).show()
            stopSelf()
            return
        }
        if (floatingView == null) {
            createFloatingView()
        }
        MediaSessionBridge.registerListener(mediaStateListener)
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
        restartProgressTicker()
    }

    private fun restartProgressTicker() {
        mainHandler.removeCallbacks(progressTicker)
        if (!isMiniMode && floatingView != null) {
            mainHandler.post(progressTicker)
        }
    }

    private fun startOverlayForeground() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.notification_channel_desc)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }

            val stopIntent = Intent(this, FloatingWidgetService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            val stopPendingIntent = PendingIntent.getService(
                this,
                0,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val openAppIntent = Intent(this, MainActivity::class.java)
            val openAppPendingIntent = PendingIntent.getActivity(
                this,
                1,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
            }

            val action = Notification.Action.Builder(
                R.drawable.ic_close,
                getString(R.string.action_close_bubble),
                stopPendingIntent
            ).build()

            val notification = builder
                .setSmallIcon(R.drawable.ic_music_note)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notification_active_text))
                .setContentIntent(openAppPendingIntent)
                .addAction(action)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun createFloatingView() {
        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val inflater = LayoutInflater.from(this)
            val rootView = inflater.inflate(R.layout.layout_floating_widget, null)
            floatingView = rootView

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 36
                y = 240
            }

            expandedCard = rootView.findViewById(R.id.expandedCard)
            ivExpandedArt = rootView.findViewById(R.id.ivExpandedArt)
            tvOpenAppBadge = rootView.findViewById(R.id.tvOpenAppBadge)
            tvTrackTitle = rootView.findViewById(R.id.tvTrackTitle)
            tvArtistName = rootView.findViewById(R.id.tvArtistName)
            seekProgress = rootView.findViewById(R.id.seekProgress)
            tvTimeNow = rootView.findViewById(R.id.tvTimeNow)
            tvTimeRemaining = rootView.findViewById(R.id.tvTimeRemaining)
            tvTimeTotal = rootView.findViewById(R.id.tvTimeTotal)
            btnRewind5 = rootView.findViewById(R.id.btnRewind5)
            btnPlayPauseExpanded = rootView.findViewById(R.id.btnPlayPauseExpanded)
            btnForward5 = rootView.findViewById(R.id.btnForward5)

            miniCard = rootView.findViewById(R.id.miniCard)
            ivMiniArtBg = rootView.findViewById(R.id.ivMiniArtBg)
            vMiniScrim = rootView.findViewById(R.id.vMiniScrim)
            btnMiniRewind5 = rootView.findViewById(R.id.btnMiniRewind5)
            btnMiniPlayPause = rootView.findViewById(R.id.btnMiniPlayPause)
            btnMiniForward5 = rootView.findViewById(R.id.btnMiniForward5)

            tvTrackTitle?.isSelected = true
            tvArtistName?.isSelected = true

            // Interactive SeekBar in Expanded Mode
            seekProgress?.max = 1000
            seekProgress?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && latestState.durationMs > 0L) {
                        val targetMs = (latestState.durationMs * progress) / 1000L
                        val remMs = (latestState.durationMs - targetMs).coerceAtLeast(0L)
                        tvTimeNow?.text = formatTimeMs(targetMs)
                        tvTimeRemaining?.text = "-${formatTimeMs(remMs)}"
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = true
                }

                override fun onStopTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = false
                    val progress = sb?.progress ?: 0
                    if (latestState.durationMs > 0L) {
                        val targetMs = (latestState.durationMs * progress) / 1000L
                        MediaSessionBridge.seekToPositionMs(targetMs, this@FloatingWidgetService)
                    }
                }
            })

            // 1. Expanded Album Art:
            //    - Single Tap: Minimize to Circular Mini Mode
            //    - Double Tap: Open Floating Session Picker Dialog!
            //    - Hold (320ms): Minimize to Circular Mini Mode
            //    - Long-Long Hold (1350ms): Close & Stop Bubble
            ivExpandedArt?.let { art ->
                attachTwoStageHoldAndDragHandler(
                    targetView = art,
                    onTap = { toggleMiniMode() },
                    onDoubleTap = {
                        triggerStrongHaptic(isDoublePulse = false)
                        showFloatingSessionPickerDialog()
                    },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 2. Open Player App Badge ("↗ App") + Title + Artist:
            //    - Single Tap: Opens the currently playing app (Spotify, YouTube Music, etc.)!
            //    - Double Tap: Opens Session Picker Dialog!
            val openPlayerAction: () -> Unit = {
                triggerStrongHaptic(isDoublePulse = false)
                val opened = MediaSessionBridge.openCurrentMediaApp(this)
                if (!opened) {
                    // Fallback to opening our own settings screen if no active session
                    val intent = Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                }
            }
            tvOpenAppBadge?.let { badge ->
                attachTwoStageHoldAndDragHandler(
                    targetView = badge,
                    onTap = openPlayerAction,
                    onDoubleTap = { showFloatingSessionPickerDialog() },
                    onStage1Hold = { showFloatingSessionPickerDialog() },
                    onStage2Hold = null
                )
            }
            tvTrackTitle?.let { tv ->
                attachTwoStageHoldAndDragHandler(
                    targetView = tv,
                    onTap = openPlayerAction,
                    onDoubleTap = { showFloatingSessionPickerDialog() },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            tvArtistName?.let { tv ->
                attachTwoStageHoldAndDragHandler(
                    targetView = tv,
                    onTap = openPlayerAction,
                    onDoubleTap = { showFloatingSessionPickerDialog() },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 3. Expanded Play/Pause Button:
            //    - Tap: Play/Pause
            //    - Hold (320ms): Minimize to Circular Mini Mode
            //    - Long-Long Hold (1350ms): Close & Stop Bubble
            btnPlayPauseExpanded?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onDoubleTap = null,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 4. Expanded -5s / +5s Buttons (Tap: ±5s, Hold 320ms: Previous / Next Track)
            btnRewind5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(-5_000L, this) },
                    onDoubleTap = null,
                    onStage1Hold = { MediaSessionBridge.skipPreviousTrack(this) },
                    onStage2Hold = null
                )
            }
            btnForward5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(5_000L, this) },
                    onDoubleTap = null,
                    onStage1Hold = { MediaSessionBridge.skipNextTrack(this) },
                    onStage2Hold = null
                )
            }

            // 5. Minimized Circular Bubble Controls:
            //    - Center Play/Pause: Tap = Play/Pause | Hold (320ms) = Expand | Long-Long Hold (1350ms) = Close
            //    - Left -5s: Tap = -5s | Hold (320ms) = Previous Track
            //    - Right +5s: Tap = +5s | Hold (320ms) = Next Track
            btnMiniPlayPause?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onDoubleTap = null,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            btnMiniRewind5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(-5_000L, this) },
                    onDoubleTap = null,
                    onStage1Hold = { MediaSessionBridge.skipPreviousTrack(this) },
                    onStage2Hold = null
                )
            }
            btnMiniForward5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(5_000L, this) },
                    onDoubleTap = null,
                    onStage1Hold = { MediaSessionBridge.skipNextTrack(this) },
                    onStage2Hold = null
                )
            }
            miniCard?.let { card ->
                attachTwoStageHoldAndDragHandler(
                    targetView = card,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onDoubleTap = null,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 6. Dragging from card background
            expandedCard?.let { card ->
                attachTwoStageHoldAndDragHandler(
                    targetView = card,
                    onTap = null,
                    onDoubleTap = { showFloatingSessionPickerDialog() },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            windowManager?.addView(rootView, layoutParams)
            updateWidgetUi(latestState)
            restartProgressTicker()
        } catch (t: Throwable) {
            Toast.makeText(
                applicationContext,
                "Overlay error: ${t.javaClass.simpleName}: ${t.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun toggleMiniMode() {
        isMiniMode = !isMiniMode
        expandedCard?.visibility = if (isMiniMode) View.GONE else View.VISIBLE
        miniCard?.visibility = if (isMiniMode) View.VISIBLE else View.GONE
        restartProgressTicker()
        floatingView?.let { view ->
            try {
                windowManager?.updateViewLayout(view, layoutParams)
            } catch (_: Throwable) {
            }
        }
    }

    private fun closeBubbleWithFeedback() {
        triggerStrongHaptic(isDoublePulse = true)
        Toast.makeText(
            applicationContext,
            getString(R.string.toast_bubble_closed),
            Toast.LENGTH_SHORT
        ).show()
        stopSelf()
    }

    /**
     * Shows a sleek Material 3 floating overlay dialog right over the screen when the user
     * double-taps the Expanded Album Art, allowing them to switch active media sessions,
     * open the currently playing app, or open Bubble Settings!
     */
    private fun showFloatingSessionPickerDialog() {
        dismissSessionPickerPopup()
        try {
            val wm = windowManager ?: return
            val density = resources.displayMetrics.density
            val palette = BubblePrefs.resolvePalette(this, latestState.squareArt)

            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val pad = (16 * density).toInt()
                setPadding(pad, pad, pad, pad)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 24f * density
                    setColor(Color.argb(242, 18, 20, 28))
                    setStroke((1.5f * density).toInt().coerceAtLeast(1), palette.accentColor)
                }
            }

            val titleTv = TextView(this).apply {
                text = "Select Media Session"
                setTextColor(Color.WHITE)
                textSize = 15f
                paint.isFakeBoldText = true
            }
            container.addView(titleTv)

            val subTv = TextView(this).apply {
                text = "Pick which app the bubble controls:"
                setTextColor(Color.parseColor("#9CA3AF"))
                textSize = 12f
                setPadding(0, (2 * density).toInt(), 0, (10 * density).toInt())
            }
            container.addView(subTv)

            val sessions = MediaSessionBridge.getAvailableSessionsSnapshot(this)
            val currentTarget = BubblePrefs.getTargetPackage(this)

            // Helper to add a session option button
            fun addOptionButton(label: String, isSelected: Boolean, onClick: () -> Unit) {
                val btn = Button(this).apply {
                    text = if (isSelected) "✓  $label" else "    $label"
                    isAllCaps = false
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER_VERTICAL or Gravity.START
                    val hPad = (12 * density).toInt()
                    setPadding(hPad, 0, hPad, 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 12f * density
                        if (isSelected) {
                            setColor(Color.argb(95, Color.red(palette.accentColor), Color.green(palette.accentColor), Color.blue(palette.accentColor)))
                            setStroke((1.5f * density).toInt().coerceAtLeast(1), palette.accentColor)
                        } else {
                            setColor(Color.argb(40, 255, 255, 255))
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        (230 * density).toInt(),
                        (40 * density).toInt()
                    ).apply {
                        topMargin = (6 * density).toInt()
                    }
                    setOnClickListener {
                        triggerStrongHaptic(isDoublePulse = false)
                        onClick()
                        dismissSessionPickerPopup()
                    }
                }
                container.addView(btn)
            }

            // 1. Auto option
            addOptionButton("Auto (Follow playing app)", currentTarget.isBlank()) {
                BubblePrefs.setTargetPackage(this, "")
                MediaSessionBridge.forceRefreshUi(this)
            }

            // 2. Each active session
            sessions.forEach { entry ->
                val stateIcon = if (entry.isPlaying) "▶" else "⏸"
                val display = "${entry.appLabel} ($stateIcon ${entry.title.take(18)})"
                addOptionButton(display, currentTarget == entry.packageName) {
                    BubblePrefs.setTargetPackage(this, entry.packageName)
                    MediaSessionBridge.forceRefreshUi(this)
                }
            }

            // 3. Action row: "Open Playing App ↗" & "Bubble Settings ⚙" & "Cancel"
            val actionsRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = (12 * density).toInt()
                }
            }

            fun makeActionPill(label: String, textColor: Int, onClick: () -> Unit): Button {
                return Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = 11.5f
                    setTextColor(textColor)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 10f * density
                        setColor(Color.argb(45, 255, 255, 255))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        0,
                        (36 * density).toInt(),
                        1f
                    ).apply {
                        marginEnd = (4 * density).toInt()
                        marginStart = (4 * density).toInt()
                    }
                    setOnClickListener {
                        onClick()
                        dismissSessionPickerPopup()
                    }
                }
            }

            actionsRow.addView(makeActionPill("Open Player ↗", Color.parseColor("#93C5FD")) {
                MediaSessionBridge.openCurrentMediaApp(this)
            })
            actionsRow.addView(makeActionPill("Settings ⚙", Color.parseColor("#E5E7EB")) {
                val i = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(i)
            })
            actionsRow.addView(makeActionPill("Close", Color.parseColor("#F87171")) {
                // Just closes popup
            })
            container.addView(actionsRow)

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            val popupParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            container.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    dismissSessionPickerPopup()
                    true
                } else {
                    false
                }
            }

            sessionPickerView = container
            wm.addView(container, popupParams)
        } catch (_: Throwable) {
        }
    }

    private fun dismissSessionPickerPopup() {
        sessionPickerView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Throwable) {
            }
        }
        sessionPickerView = null
    }

    /**
     * Unified touch handler supporting:
     * - Smooth dragging
     * - Single Tap & Double Tap (e.g. Double-tap Album Art -> Session Picker Dialog)
     * - Fast Stage 1 Hold (320ms) -> Strong haptic + Expand/Minimize
     * - Stage 2 Long-Long Hold (1350ms) -> Double-pulse strong haptic + Close Bubble
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachTwoStageHoldAndDragHandler(
        targetView: View,
        onTap: (() -> Unit)?,
        onDoubleTap: (() -> Unit)?,
        onStage1Hold: (() -> Unit)?,
        onStage2Hold: (() -> Unit)?
    ) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var stage1Reached = false
        var stage2Triggered = false
        var lastTapTimeMs = 0L

        val singleTapRunnable = Runnable {
            onTap?.invoke()
        }

        val stage1Runnable = Runnable {
            if (!isDragging && onStage1Hold != null) {
                stage1Reached = true
                targetView.performHapticFeedback(
                    HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                )
                triggerStrongHaptic(isDoublePulse = false)
                if (onStage2Hold == null) {
                    onStage1Hold.invoke()
                }
            }
        }

        val stage2Runnable = Runnable {
            if (!isDragging && onStage2Hold != null) {
                stage2Triggered = true
                targetView.performHapticFeedback(
                    HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                )
                onStage2Hold.invoke()
            }
        }

        targetView.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    stage1Reached = false
                    stage2Triggered = false

                    if (onStage1Hold != null) {
                        mainHandler.postDelayed(stage1Runnable, HOLD_EXPAND_MS)
                    }
                    if (onStage2Hold != null) {
                        mainHandler.postDelayed(stage2Runnable, HOLD_CLOSE_MS)
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                        v.isPressed = false
                        mainHandler.removeCallbacks(stage1Runnable)
                        mainHandler.removeCallbacks(stage2Runnable)
                        mainHandler.removeCallbacks(singleTapRunnable)
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        floatingView?.let { view ->
                            try {
                                windowManager?.updateViewLayout(view, layoutParams)
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(stage1Runnable)
                    mainHandler.removeCallbacks(stage2Runnable)
                    if (!isDragging && !stage2Triggered) {
                        if (stage1Reached) {
                            if (onStage2Hold != null) {
                                onStage1Hold?.invoke()
                            }
                        } else {
                            val now = SystemClock.uptimeMillis()
                            if (onDoubleTap != null && (now - lastTapTimeMs) <= DOUBLE_TAP_WINDOW_MS) {
                                mainHandler.removeCallbacks(singleTapRunnable)
                                lastTapTimeMs = 0L
                                onDoubleTap.invoke()
                            } else {
                                lastTapTimeMs = now
                                if (onDoubleTap != null) {
                                    mainHandler.postDelayed(singleTapRunnable, DOUBLE_TAP_WINDOW_MS)
                                } else {
                                    onTap?.invoke()
                                }
                            }
                        }
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(stage1Runnable)
                    mainHandler.removeCallbacks(stage2Runnable)
                    true
                }

                else -> false
            }
        }
    }

    private fun updateWidgetUi(state: MediaSessionBridge.MediaUiState) {
        val density = resources.displayMetrics.density
        val palette = BubblePrefs.resolvePalette(this, state.squareArt)

        // 1. Expanded Card Material 3 Tonal Background
        val cardBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 26f * density
            setColor(palette.cardSurfaceColor)
            setStroke((1.3f * density).toInt().coerceAtLeast(1), palette.strokeColor)
        }
        expandedCard?.background = cardBg

        // 2. Open Player App Badge ("↗ AppName")
        val badgeLabel = if (state.appLabel.isNotBlank() && state.hasActiveSession) {
            "↗ ${state.appLabel}"
        } else {
            "↗ Open App"
        }
        tvOpenAppBadge?.text = badgeLabel
        tvOpenAppBadge?.setTextColor(palette.onAccentColor)
        tvOpenAppBadge?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 10f * density
            setColor(palette.accentColor)
        }

        // 3. Expanded Play/Pause Squircle Button
        val playBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f * density
            setColor(palette.accentColor)
        }
        btnPlayPauseExpanded?.background = playBtnBg
        btnPlayPauseExpanded?.setColorFilter(palette.onAccentColor)

        // 4. Minimized Circular Card (Circle shape with Album Art + Opacity + -5s / Play / +5s)
        val miniScrimAlpha = (palette.opacityAlpha * 0.52f).toInt().coerceIn(30, 185)
        val miniCircleBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(
                Color.argb(
                    if (state.circleArt != null) miniScrimAlpha else palette.opacityAlpha,
                    Color.red(palette.cardSurfaceColor),
                    Color.green(palette.cardSurfaceColor),
                    Color.blue(palette.cardSurfaceColor)
                )
            )
            setStroke((1.8f * density).toInt().coerceAtLeast(1), palette.accentColor)
        }
        vMiniScrim?.background = miniCircleBg

        // 5. Separate Track Title and Artist Name
        if (tvTrackTitle?.text?.toString() != state.title) {
            tvTrackTitle?.text = state.title
            tvTrackTitle?.isSelected = true
        }
        tvTrackTitle?.setTextColor(palette.primaryTextColor)

        if (tvArtistName?.text?.toString() != state.artist) {
            tvArtistName?.text = state.artist
            tvArtistName?.isSelected = true
        }
        tvArtistName?.setTextColor(palette.secondaryTextColor)

        // 6. Play/Pause Icons
        val playIconRes = if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        btnPlayPauseExpanded?.setImageResource(playIconRes)
        btnMiniPlayPause?.setImageResource(playIconRes)

        // 7. Apply Opacity directly to Album Art (both Expanded Square & Minimized Circle!)
        ivExpandedArt?.imageAlpha = palette.opacityAlpha
        ivMiniArtBg?.imageAlpha = palette.opacityAlpha

        if (state.squareArt != null && state.circleArt != null) {
            ivExpandedArt?.scaleType = ImageView.ScaleType.FIT_XY
            ivExpandedArt?.setImageBitmap(state.squareArt)
            ivExpandedArt?.clearColorFilter()

            ivMiniArtBg?.scaleType = ImageView.ScaleType.FIT_XY
            ivMiniArtBg?.setImageBitmap(state.circleArt)
            ivMiniArtBg?.clearColorFilter()
        } else {
            ivExpandedArt?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivExpandedArt?.setImageResource(R.drawable.ic_music_note)
            ivExpandedArt?.setColorFilter(palette.accentColor)

            ivMiniArtBg?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivMiniArtBg?.setImageResource(R.drawable.ic_music_note)
            ivMiniArtBg?.setColorFilter(palette.accentColor)
        }

        // 8. Update Time & Progress Bar immediately
        updateProgressUi()
    }

    private fun updateProgressUi() {
        if (isUserSeeking) return
        val duration = latestState.durationMs
        val current = MediaSessionBridge.getCurrentPositionMs()
        if (duration > 0L) {
            val remaining = (duration - current).coerceAtLeast(0L)
            tvTimeNow?.text = formatTimeMs(current)
            tvTimeRemaining?.text = "-${formatTimeMs(remaining)}"
            tvTimeTotal?.text = formatTimeMs(duration)
            val progressPermille = ((current * 1000L) / duration).toInt().coerceIn(0, 1000)
            seekProgress?.progress = progressPermille
            seekProgress?.isEnabled = true
        } else {
            tvTimeNow?.text = formatTimeMs(current)
            tvTimeRemaining?.text = "-0:00"
            tvTimeTotal?.text = "0:00"
            seekProgress?.progress = 0
            seekProgress?.isEnabled = false
        }
    }

    private fun formatTimeMs(ms: Long): String {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, seconds)
        }
    }

    /**
     * Strong, unmistakable haptic feedback using full 255 amplitude and USAGE_ALARM/USAGE_TOUCH
     * so Android's background service restrictions never mute the vibration.
     */
    private fun triggerStrongHaptic(isDoublePulse: Boolean) {
        try {
            val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator == null || !vibrator.hasVibrator()) return

            val effect = if (isDoublePulse) {
                // Strong double-pulse for closing the bubble
                VibrationEffect.createWaveform(
                    longArrayOf(0L, 95L, 65L, 130L),
                    intArrayOf(0, 255, 0, 255),
                    -1
                )
            } else {
                // Crisp, max-strength 85ms pulse for Expand/Minimize & Session Picker
                VibrationEffect.createOneShot(85L, 255)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val attrs = VibrationAttributes.Builder()
                    .setUsage(VibrationAttributes.USAGE_ALARM)
                    .build()
                vibrator.vibrate(effect, attrs)
            } else {
                @Suppress("DEPRECATION")
                val audioAttrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                @Suppress("DEPRECATION")
                vibrator.vibrate(effect, audioAttrs)
            }
        } catch (_: Throwable) {
        }
    }

    private fun removeFloatingView() {
        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Throwable) {
            }
        }
        floatingView = null
    }
}
