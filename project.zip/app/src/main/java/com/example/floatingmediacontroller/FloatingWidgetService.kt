package com.example.floatingmediacontroller

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingWidgetService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_media_overlay_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_OVERLAY = "com.example.floatingmediacontroller.ACTION_STOP_OVERLAY"
        const val ACTION_REFRESH_STYLE = "com.example.floatingmediacontroller.ACTION_REFRESH_STYLE"

        // Stage 1 hold (500ms) = Toggle Expand / Minimize
        private const val HOLD_EXPAND_MS = 500L
        // Stage 2 long-long hold (1650ms) = Close & Stop Bubble
        private const val HOLD_CLOSE_MS = 1650L
    }

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    // Expanded View Elements (Vertical Square Card: Rounded Square Album Art on Top + Title + Controls Row)
    private var expandedCard: LinearLayout? = null
    private var ivExpandedArt: ImageView? = null
    private var tvTrackTitle: TextView? = null
    private var btnRewind5: ImageButton? = null
    private var btnPlayPauseExpanded: ImageButton? = null
    private var btnForward5: ImageButton? = null

    // Minimized View Elements (Single Rounded Square where Album Art IS the background of Play/Pause button)
    private var miniCard: FrameLayout? = null
    private var ivMiniArtBg: ImageView? = null
    private var vMiniScrim: View? = null
    private var ivMiniPlayIcon: ImageView? = null

    private var isMiniMode = false
    private var latestState = MediaSessionBridge.MediaUiState()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val mediaStateListener: (MediaSessionBridge.MediaUiState) -> Unit = { state ->
        latestState = state
        updateWidgetUi(state)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startOverlayForeground()
        ensureBubbleShown()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH_STYLE -> {
                ensureBubbleShown()
                updateWidgetUi(latestState)
                return START_STICKY
            }
        }
        startOverlayForeground()
        ensureBubbleShown()
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
        // Proactively trim heap after initialization to keep RAM minimal
        mainHandler.postDelayed({ System.gc() }, 400L)
        return START_STICKY
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            System.gc()
        }
    }

    override fun onDestroy() {
        MediaSessionBridge.unregisterListener(mediaStateListener)
        removeFloatingView()
        super.onDestroy()
    }

    private fun ensureBubbleShown() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                applicationContext,
                getString(R.string.msg_enable_overlay_first),
                Toast.LENGTH_SHORT
            ).show()
            stopSelf()
            return
        }
        if (floatingView == null) {
            createFloatingView()
        }
        MediaSessionBridge.registerListener(mediaStateListener)
        MediaListenerService.ensureConnected(this)
        MediaSessionBridge.pollActiveSessions(this)
    }

    private fun startOverlayForeground() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.notification_channel_desc)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }

            val stopIntent = Intent(this, FloatingWidgetService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            val stopPendingIntent = PendingIntent.getService(
                this,
                0,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val openAppIntent = Intent(this, MainActivity::class.java)
            val openAppPendingIntent = PendingIntent.getActivity(
                this,
                1,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
            }

            val action = Notification.Action.Builder(
                R.drawable.ic_close,
                getString(R.string.action_close_bubble),
                stopPendingIntent
            ).build()

            val notification = builder
                .setSmallIcon(R.drawable.ic_music_note)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notification_active_text))
                .setContentIntent(openAppPendingIntent)
                .addAction(action)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun createFloatingView() {
        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val inflater = LayoutInflater.from(this)
            val rootView = inflater.inflate(R.layout.layout_floating_widget, null)
            floatingView = rootView

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 40
                y = 260
            }

            expandedCard = rootView.findViewById(R.id.expandedCard)
            ivExpandedArt = rootView.findViewById(R.id.ivExpandedArt)
            tvTrackTitle = rootView.findViewById(R.id.tvTrackTitle)
            btnRewind5 = rootView.findViewById(R.id.btnRewind5)
            btnPlayPauseExpanded = rootView.findViewById(R.id.btnPlayPauseExpanded)
            btnForward5 = rootView.findViewById(R.id.btnForward5)

            miniCard = rootView.findViewById(R.id.miniCard)
            ivMiniArtBg = rootView.findViewById(R.id.ivMiniArtBg)
            vMiniScrim = rootView.findViewById(R.id.vMiniScrim)
            ivMiniPlayIcon = rootView.findViewById(R.id.ivMiniPlayIcon)

            // Rounded-square outline clipping for Expanded Album Art (18dp radius) and Mini Button (20dp radius)
            val density = resources.displayMetrics.density
            ivExpandedArt?.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 18f * density)
                }
            }
            ivExpandedArt?.clipToOutline = true

            miniCard?.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 20f * density)
                }
            }
            miniCard?.clipToOutline = true

            tvTrackTitle?.isSelected = true

            // 1. Expanded Album Art:
            //    - Single Tap: Minimize to Mini Mode
            //    - Long Press (0.5s): Minimize to Mini Mode
            //    - Long-Long Press (1.65s): Close & Stop Bubble
            ivExpandedArt?.let { art ->
                attachTwoStageHoldAndDragHandler(
                    targetView = art,
                    onTap = { toggleMiniMode() },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 2. Expanded Play/Pause Button:
            //    - Single Tap: Play / Pause
            //    - Long Press (0.5s): Minimize to Mini Mode
            //    - Long-Long Press (1.65s): Close & Stop Bubble
            btnPlayPauseExpanded?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 3. Minimized Mode Play/Stop Button (with Album Art as its background):
            //    - Single Tap: Play / Pause
            //    - Long Press (0.5s): Expand to full vertical card
            //    - Long-Long Press (1.65s): Close & Stop Bubble
            miniCard?.let { mini ->
                attachTwoStageHoldAndDragHandler(
                    targetView = mini,
                    onTap = { MediaSessionBridge.togglePlayPause(this) },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            // 4. -5s Button (Single Tap: -5s, Hold 0.5s: Previous Track)
            btnRewind5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(-5_000L, this) },
                    onStage1Hold = { MediaSessionBridge.skipPreviousTrack(this) },
                    onStage2Hold = null
                )
            }

            // 5. +5s Button (Single Tap: +5s, Hold 0.5s: Next Track)
            btnForward5?.let { btn ->
                attachTwoStageHoldAndDragHandler(
                    targetView = btn,
                    onTap = { MediaSessionBridge.seekByMilliseconds(5_000L, this) },
                    onStage1Hold = { MediaSessionBridge.skipNextTrack(this) },
                    onStage2Hold = null
                )
            }

            // 6. Dragging from card background or title text
            expandedCard?.let { card ->
                attachTwoStageHoldAndDragHandler(
                    targetView = card,
                    onTap = null,
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }
            tvTrackTitle?.let { tv ->
                attachTwoStageHoldAndDragHandler(
                    targetView = tv,
                    onTap = { toggleMiniMode() },
                    onStage1Hold = { toggleMiniMode() },
                    onStage2Hold = { closeBubbleWithFeedback() }
                )
            }

            windowManager?.addView(rootView, layoutParams)
            updateWidgetUi(latestState)
        } catch (t: Throwable) {
            Toast.makeText(
                applicationContext,
                "Overlay error: ${t.javaClass.simpleName}: ${t.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun toggleMiniMode() {
        isMiniMode = !isMiniMode
        expandedCard?.visibility = if (isMiniMode) View.GONE else View.VISIBLE
        miniCard?.visibility = if (isMiniMode) View.VISIBLE else View.GONE
        floatingView?.let { view ->
            try {
                windowManager?.updateViewLayout(view, layoutParams)
            } catch (_: Throwable) {
            }
        }
    }

    private fun closeBubbleWithFeedback() {
        triggerHaptic(85L)
        Toast.makeText(
            applicationContext,
            getString(R.string.toast_bubble_closed),
            Toast.LENGTH_SHORT
        ).show()
        stopSelf()
    }

    /**
     * Supports smooth dragging plus:
     * - Quick tap -> [onTap]
     * - Hold 500ms (Stage 1) -> Haptic tick (if released before 1650ms, triggers [onStage1Hold], e.g. Expand/Minimize)
     * - Hold 1650ms (Stage 2, "long-long press") -> Stronger haptic + immediately triggers [onStage2Hold] (Close bubble)
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachTwoStageHoldAndDragHandler(
        targetView: View,
        onTap: (() -> Unit)?,
        onStage1Hold: (() -> Unit)?,
        onStage2Hold: (() -> Unit)?
    ) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var stage1Reached = false
        var stage2Triggered = false

        val stage1Runnable = Runnable {
            if (!isDragging && onStage1Hold != null) {
                stage1Reached = true
                triggerHaptic(30L)
                // If there is no Stage 2 action (e.g. -5s/+5s track skip), fire Stage 1 immediately
                if (onStage2Hold == null) {
                    onStage1Hold.invoke()
                }
            }
        }

        val stage2Runnable = Runnable {
            if (!isDragging && onStage2Hold != null) {
                stage2Triggered = true
                onStage2Hold.invoke()
            }
        }

        targetView.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    stage1Reached = false
                    stage2Triggered = false

                    if (onStage1Hold != null) {
                        mainHandler.postDelayed(stage1Runnable, HOLD_EXPAND_MS)
                    }
                    if (onStage2Hold != null) {
                        mainHandler.postDelayed(stage2Runnable, HOLD_CLOSE_MS)
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                        v.isPressed = false
                        mainHandler.removeCallbacks(stage1Runnable)
                        mainHandler.removeCallbacks(stage2Runnable)
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        floatingView?.let { view ->
                            try {
                                windowManager?.updateViewLayout(view, layoutParams)
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(stage1Runnable)
                    mainHandler.removeCallbacks(stage2Runnable)
                    if (!isDragging && !stage2Triggered) {
                        if (stage1Reached) {
                            // Released after Stage 1 (0.5s) but before Stage 2 (1.65s) -> Expand/Minimize!
                            if (onStage2Hold != null) {
                                onStage1Hold?.invoke()
                            }
                        } else {
                            onTap?.invoke()
                        }
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    mainHandler.removeCallbacks(stage1Runnable)
                    mainHandler.removeCallbacks(stage2Runnable)
                    true
                }

                else -> false
            }
        }
    }

    private fun updateWidgetUi(state: MediaSessionBridge.MediaUiState) {
        val density = resources.displayMetrics.density
        val palette = BubblePrefs.resolvePalette(this, state.albumArt)

        // Apply Material 3 dynamic tonal card background + border stroke to Expanded Card
        val cardBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 26f * density
            setColor(palette.cardSurfaceColor)
            setStroke((1.2f * density).toInt().coerceAtLeast(1), palette.strokeColor)
        }
        expandedCard?.background = cardBg

        // Apply Material 3 dynamic accent pill to Play/Pause button in Expanded Mode
        val playBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f * density
            setColor(palette.accentColor)
        }
        btnPlayPauseExpanded?.background = playBtnBg
        btnPlayPauseExpanded?.setColorFilter(palette.onAccentColor)

        // Apply translucent scrim + border to Minimized Button
        val opacity = BubblePrefs.getOpacityPercent(this)
        val miniScrimAlpha = ((opacity / 100f) * 135f).toInt().coerceIn(35, 190)
        val miniScrimBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 20f * density
            setColor(Color.argb(miniScrimBgAlpha(state.albumArt != null, miniScrimAlpha, palette.cardSurfaceColor),
                Color.red(palette.cardSurfaceColor),
                Color.green(palette.cardSurfaceColor),
                Color.blue(palette.cardSurfaceColor)
            ))
            setStroke((1.5f * density).toInt().coerceAtLeast(1), palette.accentColor)
        }
        vMiniScrim?.background = miniScrimBg

        // Update Title Text
        val displayTitle = if (state.artist.isNotBlank() && state.hasActiveSession) {
            "${state.title} • ${state.artist}"
        } else {
            state.title
        }
        if (tvTrackTitle?.text?.toString() != displayTitle) {
            tvTrackTitle?.text = displayTitle
            tvTrackTitle?.isSelected = true
        }
        tvTrackTitle?.setTextColor(palette.primaryTextColor)

        // Update Play/Pause Icons
        val playIconRes = if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        btnPlayPauseExpanded?.setImageResource(playIconRes)
        ivMiniPlayIcon?.setImageResource(playIconRes)

        // Update Album Art in both Expanded Square & Minimized Button Background
        if (state.albumArt != null) {
            ivExpandedArt?.scaleType = ImageView.ScaleType.CENTER_CROP
            ivExpandedArt?.setImageBitmap(state.albumArt)
            ivExpandedArt?.clearColorFilter()

            ivMiniArtBg?.scaleType = ImageView.ScaleType.CENTER_CROP
            ivMiniArtBg?.setImageBitmap(state.albumArt)
            ivMiniArtBg?.clearColorFilter()
        } else {
            ivExpandedArt?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivExpandedArt?.setImageResource(R.drawable.ic_music_note)
            ivExpandedArt?.setColorFilter(palette.accentColor)

            ivMiniArtBg?.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivMiniArtBg?.setImageResource(R.drawable.ic_music_note)
            ivMiniArtBg?.setColorFilter(palette.accentColor)
        }
    }

    private fun miniScrimBgAlpha(hasArt: Boolean, baseAlpha: Int, surfaceColor: Int): Int {
        return if (hasArt) baseAlpha else Color.alpha(surfaceColor)
    }

    private fun triggerHaptic(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager =
                    getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun removeFloatingView() {
        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Throwable) {
            }
        }
        floatingView = null
    }
}
