package com.example.floatingmediacontroller

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

object MediaSessionBridge {

    data class SessionEntry(
        val packageName: String,
        val appLabel: String,
        val title: String,
        val artist: String,
        val isPlaying: Boolean
    )

    data class MediaUiState(
        val packageName: String = "",
        val appLabel: String = "",
        val title: String = "No media playing",
        val artist: String = "Tap art to open player",
        val isPlaying: Boolean = false,
        val squareArt: Bitmap? = null,
        val durationMs: Long = 0L,
        val hasActiveSession: Boolean = false
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeController: MediaController? = null
    private var allControllers: List<MediaController> = emptyList()
    private var currentState = MediaUiState()
    private val listeners = mutableSetOf<(MediaUiState) -> Unit>()
    private val sessionListListeners = mutableSetOf<(List<SessionEntry>) -> Unit>()

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            rebuildAndNotify()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            rebuildAndNotify()
        }

        override fun onSessionDestroyed() {
            setController(null)
        }
    }

    fun pollActiveSessions(context: Context) {
        try {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
                ?: return
            val cn = ComponentName(context, MediaListenerService::class.java)
            val controllers = manager.getActiveSessions(cn) ?: emptyList()
            updateControllersList(context, controllers)
        } catch (_: SecurityException) {
        } catch (_: Throwable) {
        }
    }

    fun getAvailableSessionsSnapshot(context: Context): List<SessionEntry> {
        pollActiveSessions(context)
        return allControllers.map { ctrl ->
            val pkg = ctrl.packageName ?: ""
            val label = resolveAppLabel(context, pkg)
            val title = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: "Ready"
            val artist = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: ""
            val playing = isControllerPlaying(ctrl)
            SessionEntry(pkg, label, title, artist, playing)
        }
    }

    fun updateControllersList(context: Context, controllers: List<MediaController>) {
        allControllers = controllers
        val entries = controllers.map { ctrl ->
            val pkg = ctrl.packageName ?: ""
            val label = resolveAppLabel(context, pkg)
            val title = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: "Ready"
            val artist = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: ""
            val playing = isControllerPlaying(ctrl)
            SessionEntry(pkg, label, title, artist, playing)
        }
        mainHandler.post {
            sessionListListeners.forEach { it(entries) }
        }

        if (controllers.isEmpty()) {
            setController(null, context)
            return
        }

        val preferredPkg = BubblePrefs.getTargetPackage(context)
        val chosen = when {
            preferredPkg.isNotBlank() -> {
                controllers.firstOrNull { it.packageName == preferredPkg }
                    ?: controllers.firstOrNull { isControllerPlaying(it) }
                    ?: controllers.first()
            }
            else -> {
                controllers.firstOrNull { isControllerPlaying(it) } ?: controllers.first()
            }
        }
        setController(chosen, context)
    }

    private fun isControllerPlaying(controller: MediaController): Boolean {
        val st = controller.playbackState?.state
        return st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
    }

    fun setController(controller: MediaController?, context: Context? = null) {
        if (activeController?.sessionToken == controller?.sessionToken && controller != null) {
            rebuildAndNotify(context)
            return
        }
        try {
            activeController?.unregisterCallback(controllerCallback)
        } catch (_: Throwable) {
        }
        activeController = controller
        try {
            activeController?.registerCallback(controllerCallback, mainHandler)
        } catch (_: Throwable) {
        }
        rebuildAndNotify(context)
    }

    fun registerListener(listener: (MediaUiState) -> Unit) {
        listeners.add(listener)
        listener(currentState)
    }

    fun unregisterListener(listener: (MediaUiState) -> Unit) {
        listeners.remove(listener)
    }

    fun registerSessionListListener(listener: (List<SessionEntry>) -> Unit) {
        sessionListListeners.add(listener)
    }

    fun unregisterSessionListListener(listener: (List<SessionEntry>) -> Unit) {
        sessionListListeners.remove(listener)
    }

    fun getCurrentPositionMs(): Long {
        val controller = activeController ?: return 0L
        val pbState = controller.playbackState ?: return 0L
        val duration = currentState.durationMs

        val basePos = pbState.position.coerceAtLeast(0L)
        val rawPos = if (pbState.state == PlaybackState.STATE_PLAYING) {
            val delta = (SystemClock.elapsedRealtime() - pbState.lastPositionUpdateTime).coerceAtLeast(0L)
            val speed = if (pbState.playbackSpeed > 0f) pbState.playbackSpeed else 1f
            basePos + (delta * speed).toLong()
        } else {
            basePos
        }
        return if (duration > 0L) rawPos.coerceIn(0L, duration) else rawPos.coerceAtLeast(0L)
    }

    fun seekToPositionMs(positionMs: Long, context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val duration = currentState.durationMs
            val target = if (duration > 0L) positionMs.coerceIn(0L, duration) else positionMs.coerceAtLeast(0L)
            controller.transportControls.seekTo(target)
        } catch (_: Throwable) {
        }
    }

    fun togglePlayPause(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val state = controller.playbackState?.state ?: PlaybackState.STATE_NONE
            if (state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING) {
                controller.transportControls.pause()
            } else {
                controller.transportControls.play()
            }
        } catch (_: Throwable) {
        }
    }

    fun seekByMilliseconds(deltaMs: Long, context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val current = getCurrentPositionMs()
        seekToPositionMs(current + deltaMs, context)
    }

    fun skipPreviousTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToPrevious()
        } catch (_: Throwable) {
        }
    }

    fun skipNextTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToNext()
        } catch (_: Throwable) {
        }
    }

    /**
     * Opens the currently active media player app reliably on Android 8 through Android 16!
     * Uses <queries> package visibility + ActivityOptions background start mode on Android 14/15/16.
     */
    fun openCurrentMediaApp(context: Context): Boolean {
        if (activeController == null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return false
        val pkg = controller.packageName ?: ""

        // 1. First try launching the app's main launcher Activity directly (enabled by <queries> in Manifest)
        if (pkg.isNotBlank()) {
            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                    )
                    context.startActivity(launchIntent)
                    return true
                }
            } catch (_: Throwable) {
            }
        }

        // 2. Fallback: send sessionActivity PendingIntent with Android 14/15/16 background activity start allowance
        try {
            val pi = controller.sessionActivity
            if (pi != null) {
                if (Build.VERSION.SDK_INT >= 34) {
                    val options = ActivityOptions.makeBasic()
                    options.setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                    pi.send(context, 0, null, null, null, null, options.toBundle())
                } else {
                    pi.send()
                }
                return true
            }
        } catch (_: Throwable) {
        }

        // 3. Second fallback: query intent activities for the package
        if (pkg.isNotBlank()) {
            try {
                val mainIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val resolveInfos = context.packageManager.queryIntentActivities(mainIntent, 0)
                val first = resolveInfos.firstOrNull()?.activityInfo
                if (first != null) {
                    mainIntent.component = ComponentName(first.packageName, first.name)
                    context.startActivity(mainIntent)
                    return true
                }
            } catch (_: Throwable) {
            }
        }

        return false
    }

    fun forceRefreshUi(context: Context) {
        pollActiveSessions(context)
        rebuildAndNotify(context)
    }

    fun clear() {
        val oldBmp = currentState.squareArt
        if (oldBmp != null && !oldBmp.isRecycled) {
            oldBmp.recycle()
        }
        currentState = MediaUiState()
        activeController = null
        allControllers = emptyList()
    }

    private fun rebuildAndNotify(context: Context? = null) {
        val controller = activeController
        if (controller == null) {
            val oldBmp = currentState.squareArt
            if (oldBmp != null && !oldBmp.isRecycled) {
                oldBmp.recycle()
            }
            currentState = MediaUiState()
            dispatchState()
            return
        }

        try {
            val metadata = controller.metadata
            val pbState = controller.playbackState
            val pkg = controller.packageName ?: ""
            val appName = if (context != null) resolveAppLabel(context, pkg) else pkg.substringAfterLast('.')

            val rawTitle = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            val rawArtist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)

            val duration = (metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L).coerceAtLeast(0L)

            val rawBitmap = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

            val prevBmp = currentState.squareArt
            val squareBmp = if (rawBitmap != null) {
                // If title and artist are unchanged and we already have a valid non-recycled squareArt, reuse it to prevent memory churn!
                if (prevBmp != null && !prevBmp.isRecycled && rawTitle == currentState.title && rawArtist == currentState.artist) {
                    prevBmp
                } else {
                    if (prevBmp != null && !prevBmp.isRecycled) {
                        prevBmp.recycle()
                    }
                    createRoundedSquareBitmap(rawBitmap, 256)
                }
            } else {
                if (prevBmp != null && !prevBmp.isRecycled) {
                    prevBmp.recycle()
                }
                null
            }

            val playing = pbState?.state == PlaybackState.STATE_PLAYING ||
                pbState?.state == PlaybackState.STATE_BUFFERING

            currentState = MediaUiState(
                packageName = pkg,
                appLabel = appName,
                title = if (!rawTitle.isNullOrBlank()) rawTitle else appName.ifBlank { "Active Media" },
                artist = if (!rawArtist.isNullOrBlank()) rawArtist else appName.ifBlank { "Playing" },
                isPlaying = playing,
                squareArt = squareBmp,
                durationMs = duration,
                hasActiveSession = true
            )
        } catch (_: Throwable) {
            val oldBmp = currentState.squareArt
            if (oldBmp != null && !oldBmp.isRecycled) {
                oldBmp.recycle()
            }
            currentState = MediaUiState()
        }
        dispatchState()
    }

    /**
     * Produces a crisp, anti-aliased 256x256 ARGB_8888 rounded square bitmap (only 1 bitmap stored in RAM!).
     */
    private fun createRoundedSquareBitmap(source: Bitmap, targetPx: Int): Bitmap {
        return try {
            val w = source.width
            val h = source.height
            if (w <= 0 || h <= 0) return source

            val cropSize = minOf(w, h)
            val cropX = (w - cropSize) / 2
            val cropY = (h - cropSize) / 2
            val cropped = Bitmap.createBitmap(source, cropX, cropY, cropSize, cropSize)
            val scaled = if (cropSize != targetPx) {
                Bitmap.createScaledBitmap(cropped, targetPx, targetPx, true)
            } else {
                cropped
            }

            val out = Bitmap.createBitmap(targetPx, targetPx, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            }
            val rect = RectF(0f, 0f, targetPx.toFloat(), targetPx.toFloat())
            val cornerRadius = targetPx * 0.20f
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, paint)

            if (scaled != source && scaled != out) {
                scaled.recycle()
            }
            if (cropped != source && cropped != scaled && cropped != out) {
                cropped.recycle()
            }
            out
        } catch (_: Throwable) {
            source
        }
    }

    private fun resolveAppLabel(context: Context, packageName: String): String {
        if (packageName.isBlank()) return "Unknown App"
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName.substringAfterLast('.')
        } catch (_: Throwable) {
            packageName
        }
    }

    private fun dispatchState() {
        val snapshot = currentState
        mainHandler.post {
            listeners.forEach { it(snapshot) }
        }
    }
}
