package com.example.floatingmediacontroller

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Ultra-low-RAM event bridge connecting MediaListenerService and FloatingWidgetService.
 * Downscales album art to 96x96px so the floating overlay uses minimal memory (<35 KB for bitmaps).
 */
object MediaSessionBridge {

    data class MediaUiState(
        val title: String = "No media playing",
        val artist: String = "Play audio in any app",
        val isPlaying: Boolean = false,
        val albumArt: Bitmap? = null,
        val hasActiveSession: Boolean = false
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeController: MediaController? = null
    private var currentState = MediaUiState()
    private val listeners = mutableSetOf<(MediaUiState) -> Unit>()

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            rebuildAndNotify()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            rebuildAndNotify()
        }

        override fun onSessionDestroyed() {
            setController(null)
        }
    }

    /**
     * Proactively queries MediaSessionManager for active sessions right now,
     * even if NotificationListenerService hasn't fired an event yet.
     */
    fun pollActiveSessions(context: Context) {
        try {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
                ?: return
            val cn = ComponentName(context, MediaListenerService::class.java)
            val controllers = manager.getActiveSessions(cn)
            if (controllers.isNullOrEmpty()) {
                setController(null)
                return
            }
            val playing = controllers.firstOrNull {
                val state = it.playbackState?.state
                state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING
            }
            setController(playing ?: controllers.first())
        } catch (_: SecurityException) {
            // Notification access not yet bound
        } catch (_: Throwable) {
        }
    }

    fun setController(controller: MediaController?) {
        if (activeController?.sessionToken == controller?.sessionToken && controller != null) {
            rebuildAndNotify()
            return
        }
        try {
            activeController?.unregisterCallback(controllerCallback)
        } catch (_: Throwable) {
        }
        activeController = controller
        try {
            activeController?.registerCallback(controllerCallback, mainHandler)
        } catch (_: Throwable) {
        }
        rebuildAndNotify()
    }

    fun registerListener(listener: (MediaUiState) -> Unit) {
        listeners.add(listener)
        listener(currentState)
    }

    fun unregisterListener(listener: (MediaUiState) -> Unit) {
        listeners.remove(listener)
    }

    fun togglePlayPause(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val state = controller.playbackState?.state ?: PlaybackState.STATE_NONE
            if (state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING) {
                controller.transportControls.pause()
            } else {
                controller.transportControls.play()
            }
        } catch (_: Throwable) {
        }
    }

    /**
     * Seeks backward or forward by [deltaMs] (e.g. -5000L for -5s, +5000L for +5s).
     */
    fun seekByMilliseconds(deltaMs: Long, context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val pbState = controller.playbackState ?: return
            val metadata = controller.metadata
            val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: -1L

            val basePosition = pbState.position
            val currentPosition = if (pbState.state == PlaybackState.STATE_PLAYING) {
                val timeDelta = SystemClock.elapsedRealtime() - pbState.lastPositionUpdateTime
                basePosition + (timeDelta * pbState.playbackSpeed).toLong()
            } else {
                basePosition
            }

            var targetPosition = (currentPosition + deltaMs).coerceAtLeast(0L)
            if (duration > 0L) {
                targetPosition = targetPosition.coerceAtMost(duration)
            }
            controller.transportControls.seekTo(targetPosition)
        } catch (_: Throwable) {
        }
    }

    fun skipPreviousTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToPrevious()
        } catch (_: Throwable) {
        }
    }

    fun skipNextTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToNext()
        } catch (_: Throwable) {
        }
    }

    private fun rebuildAndNotify() {
        val controller = activeController
        if (controller == null) {
            currentState = MediaUiState()
            dispatchState()
            return
        }

        try {
            val metadata = controller.metadata
            val pbState = controller.playbackState

            val rawTitle = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            val rawArtist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)

            val rawBitmap = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

            val smallBitmap = rawBitmap?.let { downscaleBitmap(it, 96) }

            val playing = pbState?.state == PlaybackState.STATE_PLAYING ||
                pbState?.state == PlaybackState.STATE_BUFFERING

            currentState = MediaUiState(
                title = if (!rawTitle.isNullOrBlank()) rawTitle else "Active Media",
                artist = if (!rawArtist.isNullOrBlank()) rawArtist else "",
                isPlaying = playing,
                albumArt = smallBitmap,
                hasActiveSession = true
            )
        } catch (_: Throwable) {
            currentState = MediaUiState()
        }
        dispatchState()
    }

    private fun downscaleBitmap(source: Bitmap, maxPx: Int): Bitmap {
        return try {
            val width = source.width
            val height = source.height
            if (width <= 0 || height <= 0) return source
            if (width <= maxPx && height <= maxPx) return source
            val ratio = width.toFloat() / height.toFloat()
            val targetWidth: Int
            val targetHeight: Int
            if (width > height) {
                targetWidth = maxPx
                targetHeight = (maxPx / ratio).toInt().coerceAtLeast(1)
            } else {
                targetHeight = maxPx
                targetWidth = (maxPx * ratio).toInt().coerceAtLeast(1)
            }
            Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
        } catch (_: Throwable) {
            source
        }
    }

    private fun dispatchState() {
        val snapshot = currentState
        mainHandler.post {
            listeners.forEach { it(snapshot) }
        }
    }
}
