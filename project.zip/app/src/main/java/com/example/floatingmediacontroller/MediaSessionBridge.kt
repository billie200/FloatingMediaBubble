package com.example.floatingmediacontroller

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Ultra-low-RAM event bridge connecting MediaListenerService, FloatingWidgetService, and MainActivity.
 * Stores album art as 72x72 RGB_565 (~10 KB in RAM!) and aggressively recycles unused bitmaps.
 */
object MediaSessionBridge {

    data class SessionEntry(
        val packageName: String,
        val appLabel: String,
        val title: String,
        val isPlaying: Boolean
    )

    data class MediaUiState(
        val packageName: String = "",
        val appLabel: String = "",
        val title: String = "No media playing",
        val artist: String = "Play audio in any app",
        val isPlaying: Boolean = false,
        val albumArt: Bitmap? = null,
        val hasActiveSession: Boolean = false
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeController: MediaController? = null
    private var allControllers: List<MediaController> = emptyList()
    private var currentState = MediaUiState()
    private val listeners = mutableSetOf<(MediaUiState) -> Unit>()
    private val sessionListListeners = mutableSetOf<(List<SessionEntry>) -> Unit>()

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            rebuildAndNotify()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            rebuildAndNotify()
        }

        override fun onSessionDestroyed() {
            setController(null)
        }
    }

    fun pollActiveSessions(context: Context) {
        try {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
                ?: return
            val cn = ComponentName(context, MediaListenerService::class.java)
            val controllers = manager.getActiveSessions(cn) ?: emptyList()
            updateControllersList(context, controllers)
        } catch (_: SecurityException) {
        } catch (_: Throwable) {
        }
    }

    fun updateControllersList(context: Context, controllers: List<MediaController>) {
        allControllers = controllers
        val entries = controllers.map { ctrl ->
            val pkg = ctrl.packageName ?: ""
            val label = resolveAppLabel(context, pkg)
            val title = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: "Ready"
            val playing = ctrl.playbackState?.state == PlaybackState.STATE_PLAYING ||
                ctrl.playbackState?.state == PlaybackState.STATE_BUFFERING
            SessionEntry(pkg, label, title, playing)
        }
        mainHandler.post {
            sessionListListeners.forEach { it(entries) }
        }

        if (controllers.isEmpty()) {
            setController(null, context)
            return
        }

        val preferredPkg = BubblePrefs.getTargetPackage(context)
        val chosen = when {
            preferredPkg.isNotBlank() -> {
                controllers.firstOrNull { it.packageName == preferredPkg }
                    ?: controllers.firstOrNull { isControllerPlaying(it) }
                    ?: controllers.first()
            }
            else -> {
                controllers.firstOrNull { isControllerPlaying(it) } ?: controllers.first()
            }
        }
        setController(chosen, context)
    }

    private fun isControllerPlaying(controller: MediaController): Boolean {
        val st = controller.playbackState?.state
        return st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
    }

    fun setController(controller: MediaController?, context: Context? = null) {
        if (activeController?.sessionToken == controller?.sessionToken && controller != null) {
            rebuildAndNotify(context)
            return
        }
        try {
            activeController?.unregisterCallback(controllerCallback)
        } catch (_: Throwable) {
        }
        activeController = controller
        try {
            activeController?.registerCallback(controllerCallback, mainHandler)
        } catch (_: Throwable) {
        }
        rebuildAndNotify(context)
    }

    fun registerListener(listener: (MediaUiState) -> Unit) {
        listeners.add(listener)
        listener(currentState)
    }

    fun unregisterListener(listener: (MediaUiState) -> Unit) {
        listeners.remove(listener)
    }

    fun registerSessionListListener(listener: (List<SessionEntry>) -> Unit) {
        sessionListListeners.add(listener)
    }

    fun unregisterSessionListListener(listener: (List<SessionEntry>) -> Unit) {
        sessionListListeners.remove(listener)
    }

    fun togglePlayPause(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val state = controller.playbackState?.state ?: PlaybackState.STATE_NONE
            if (state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING) {
                controller.transportControls.pause()
            } else {
                controller.transportControls.play()
            }
        } catch (_: Throwable) {
        }
    }

    fun seekByMilliseconds(deltaMs: Long, context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val pbState = controller.playbackState ?: return
            val metadata = controller.metadata
            val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: -1L

            val basePosition = pbState.position
            val currentPosition = if (pbState.state == PlaybackState.STATE_PLAYING) {
                val timeDelta = SystemClock.elapsedRealtime() - pbState.lastPositionUpdateTime
                basePosition + (timeDelta * pbState.playbackSpeed).toLong()
            } else {
                basePosition
            }

            var targetPosition = (currentPosition + deltaMs).coerceAtLeast(0L)
            if (duration > 0L) {
                targetPosition = targetPosition.coerceAtMost(duration)
            }
            controller.transportControls.seekTo(targetPosition)
        } catch (_: Throwable) {
        }
    }

    fun skipPreviousTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToPrevious()
        } catch (_: Throwable) {
        }
    }

    fun skipNextTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToNext()
        } catch (_: Throwable) {
        }
    }

    fun forceRefreshUi(context: Context) {
        pollActiveSessions(context)
        rebuildAndNotify(context)
    }

    private fun rebuildAndNotify(context: Context? = null) {
        val controller = activeController
        if (controller == null) {
            currentState = MediaUiState()
            dispatchState()
            return
        }

        try {
            val metadata = controller.metadata
            val pbState = controller.playbackState
            val pkg = controller.packageName ?: ""
            val appName = if (context != null) resolveAppLabel(context, pkg) else pkg.substringAfterLast('.')

            val rawTitle = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            val rawArtist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)

            val rawBitmap = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

            // Convert to 72x72 RGB_565 (2 bytes/pixel = only 10.3 KB in RAM!)
            val smallBitmap = rawBitmap?.let { downscaleToRgb565(it, 72) }

            val playing = pbState?.state == PlaybackState.STATE_PLAYING ||
                pbState?.state == PlaybackState.STATE_BUFFERING

            currentState = MediaUiState(
                packageName = pkg,
                appLabel = appName,
                title = if (!rawTitle.isNullOrBlank()) rawTitle else appName.ifBlank { "Active Media" },
                artist = if (!rawArtist.isNullOrBlank()) rawArtist else "",
                isPlaying = playing,
                albumArt = smallBitmap,
                hasActiveSession = true
            )
        } catch (_: Throwable) {
            currentState = MediaUiState()
        }
        dispatchState()
    }

    /**
     * Downscales album art to a compact 72x72 RGB_565 bitmap (~10 KB RAM instead of 4-12 MB!).
     */
    private fun downscaleToRgb565(source: Bitmap, targetPx: Int): Bitmap {
        return try {
            val w = source.width
            val h = source.height
            if (w <= 0 || h <= 0) return source
            val out = Bitmap.createBitmap(targetPx, targetPx, Bitmap.Config.RGB_565)
            val canvas = Canvas(out)
            // Center-crop square from source
            val size = minOf(w, h)
            val left = (w - size) / 2
            val top = (h - size) / 2
            val srcRect = Rect(left, top, left + size, top + size)
            val dstRect = Rect(0, 0, targetPx, targetPx)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(source, srcRect, dstRect, paint)
            out
        } catch (_: Throwable) {
            source
        }
    }

    private fun resolveAppLabel(context: Context, packageName: String): String {
        if (packageName.isBlank()) return "Unknown App"
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName.substringAfterLast('.')
        } catch (_: Throwable) {
            packageName
        }
    }

    private fun dispatchState() {
        val snapshot = currentState
        mainHandler.post {
            listeners.forEach { it(snapshot) }
        }
    }
}
