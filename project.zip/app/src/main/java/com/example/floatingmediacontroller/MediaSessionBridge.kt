package com.example.floatingmediacontroller

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

object MediaSessionBridge {

    data class SessionEntry(
        val packageName: String,
        val appLabel: String,
        val title: String,
        val artist: String,
        val isPlaying: Boolean
    )

    data class MediaUiState(
        val packageName: String = "",
        val appLabel: String = "",
        val title: String = "No media playing",
        val artist: String = "Tap to open player",
        val isPlaying: Boolean = false,
        val squareArt: Bitmap? = null,
        val circleArt: Bitmap? = null,
        val durationMs: Long = 0L,
        val hasActiveSession: Boolean = false
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeController: MediaController? = null
    private var allControllers: List<MediaController> = emptyList()
    private var currentState = MediaUiState()
    private val listeners = mutableSetOf<(MediaUiState) -> Unit>()
    private val sessionListListeners = mutableSetOf<(List<SessionEntry>) -> Unit>()

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            rebuildAndNotify()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            rebuildAndNotify()
        }

        override fun onSessionDestroyed() {
            setController(null)
        }
    }

    fun pollActiveSessions(context: Context) {
        try {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
                ?: return
            val cn = ComponentName(context, MediaListenerService::class.java)
            val controllers = manager.getActiveSessions(cn) ?: emptyList()
            updateControllersList(context, controllers)
        } catch (_: SecurityException) {
        } catch (_: Throwable) {
        }
    }

    fun getAvailableSessionsSnapshot(context: Context): List<SessionEntry> {
        pollActiveSessions(context)
        return allControllers.map { ctrl ->
            val pkg = ctrl.packageName ?: ""
            val label = resolveAppLabel(context, pkg)
            val title = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: "Ready"
            val artist = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: ""
            val playing = isControllerPlaying(ctrl)
            SessionEntry(pkg, label, title, artist, playing)
        }
    }

    fun updateControllersList(context: Context, controllers: List<MediaController>) {
        allControllers = controllers
        val entries = controllers.map { ctrl ->
            val pkg = ctrl.packageName ?: ""
            val label = resolveAppLabel(context, pkg)
            val title = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: "Ready"
            val artist = ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: ctrl.metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: ""
            val playing = isControllerPlaying(ctrl)
            SessionEntry(pkg, label, title, artist, playing)
        }
        mainHandler.post {
            sessionListListeners.forEach { it(entries) }
        }

        if (controllers.isEmpty()) {
            setController(null, context)
            return
        }

        val preferredPkg = BubblePrefs.getTargetPackage(context)
        val chosen = when {
            preferredPkg.isNotBlank() -> {
                controllers.firstOrNull { it.packageName == preferredPkg }
                    ?: controllers.firstOrNull { isControllerPlaying(it) }
                    ?: controllers.first()
            }
            else -> {
                controllers.firstOrNull { isControllerPlaying(it) } ?: controllers.first()
            }
        }
        setController(chosen, context)
    }

    private fun isControllerPlaying(controller: MediaController): Boolean {
        val st = controller.playbackState?.state
        return st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
    }

    fun setController(controller: MediaController?, context: Context? = null) {
        if (activeController?.sessionToken == controller?.sessionToken && controller != null) {
            rebuildAndNotify(context)
            return
        }
        try {
            activeController?.unregisterCallback(controllerCallback)
        } catch (_: Throwable) {
        }
        activeController = controller
        try {
            activeController?.registerCallback(controllerCallback, mainHandler)
        } catch (_: Throwable) {
        }
        rebuildAndNotify(context)
    }

    fun registerListener(listener: (MediaUiState) -> Unit) {
        listeners.add(listener)
        listener(currentState)
    }

    fun unregisterListener(listener: (MediaUiState) -> Unit) {
        listeners.remove(listener)
    }

    fun registerSessionListListener(listener: (List<SessionEntry>) -> Unit) {
        sessionListListeners.add(listener)
    }

    fun unregisterSessionListListener(listener: (List<SessionEntry>) -> Unit) {
        sessionListListeners.remove(listener)
    }

    /**
     * Returns live current playback position in milliseconds, accurately interpolated while playing.
     */
    fun getCurrentPositionMs(): Long {
        val controller = activeController ?: return 0L
        val pbState = controller.playbackState ?: return 0L
        val duration = currentState.durationMs

        val basePos = pbState.position.coerceAtLeast(0L)
        val rawPos = if (pbState.state == PlaybackState.STATE_PLAYING) {
            val delta = (SystemClock.elapsedRealtime() - pbState.lastPositionUpdateTime).coerceAtLeast(0L)
            val speed = if (pbState.playbackSpeed > 0f) pbState.playbackSpeed else 1f
            basePos + (delta * speed).toLong()
        } else {
            basePos
        }
        return if (duration > 0L) rawPos.coerceIn(0L, duration) else rawPos.coerceAtLeast(0L)
    }

    fun seekToPositionMs(positionMs: Long, context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val duration = currentState.durationMs
            val target = if (duration > 0L) positionMs.coerceIn(0L, duration) else positionMs.coerceAtLeast(0L)
            controller.transportControls.seekTo(target)
        } catch (_: Throwable) {
        }
    }

    fun togglePlayPause(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val controller = activeController ?: return
        try {
            val state = controller.playbackState?.state ?: PlaybackState.STATE_NONE
            if (state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING) {
                controller.transportControls.pause()
            } else {
                controller.transportControls.play()
            }
        } catch (_: Throwable) {
        }
    }

    fun seekByMilliseconds(deltaMs: Long, context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        val current = getCurrentPositionMs()
        seekToPositionMs(current + deltaMs, context)
    }

    fun skipPreviousTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToPrevious()
        } catch (_: Throwable) {
        }
    }

    fun skipNextTrack(context: Context? = null) {
        if (activeController == null && context != null) {
            pollActiveSessions(context)
        }
        try {
            activeController?.transportControls?.skipToNext()
        } catch (_: Throwable) {
        }
    }

    /**
     * Opens the currently active media player app (e.g. Spotify, YouTube Music, Apple Music, browser).
     */
    fun openCurrentMediaApp(context: Context): Boolean {
        if (activeController == null) {
            pollActiveSessions(context)
        }
        val controller = activeController
        if (controller != null) {
            // 1. Try sessionActivity PendingIntent first (takes user directly to the Now Playing screen!)
            try {
                val pi = controller.sessionActivity
                if (pi != null) {
                    pi.send()
                    return true
                }
            } catch (_: Throwable) {
            }

            // 2. Fallback to launching the package's main activity
            val pkg = controller.packageName
            if (!pkg.isNullOrBlank()) {
                try {
                    val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return true
                    }
                } catch (_: Throwable) {
                }
            }
        }
        return false
    }

    fun forceRefreshUi(context: Context) {
        pollActiveSessions(context)
        rebuildAndNotify(context)
    }

    private fun rebuildAndNotify(context: Context? = null) {
        val controller = activeController
        if (controller == null) {
            currentState = MediaUiState()
            dispatchState()
            return
        }

        try {
            val metadata = controller.metadata
            val pbState = controller.playbackState
            val pkg = controller.packageName ?: ""
            val appName = if (context != null) resolveAppLabel(context, pkg) else pkg.substringAfterLast('.')

            val rawTitle = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            val rawArtist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)

            val duration = (metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L).coerceAtLeast(0L)

            val rawBitmap = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

            // Crisp 256x256 ARGB_8888 center-cropped + pre-shaped rounded square & circle
            val squareBmp = rawBitmap?.let { createRoundedBitmap(it, 256, isCircle = false) }
            val circleBmp = rawBitmap?.let { createRoundedBitmap(it, 200, isCircle = true) }

            val playing = pbState?.state == PlaybackState.STATE_PLAYING ||
                pbState?.state == PlaybackState.STATE_BUFFERING

            currentState = MediaUiState(
                packageName = pkg,
                appLabel = appName,
                title = if (!rawTitle.isNullOrBlank()) rawTitle else appName.ifBlank { "Active Media" },
                artist = if (!rawArtist.isNullOrBlank()) rawArtist else appName.ifBlank { "Playing" },
                isPlaying = playing,
                squareArt = squareBmp,
                circleArt = circleBmp,
                durationMs = duration,
                hasActiveSession = true
            )
        } catch (_: Throwable) {
            currentState = MediaUiState()
        }
        dispatchState()
    }

    /**
     * Produces a crystal-clear, anti-aliased 256x256 ARGB_8888 rounded square or circle bitmap.
     * Pre-rounding with BitmapShader means zero GPU hardware-layer memory is needed!
     */
    private fun createRoundedBitmap(source: Bitmap, targetPx: Int, isCircle: Boolean): Bitmap {
        return try {
            val w = source.width
            val h = source.height
            if (w <= 0 || h <= 0) return source

            // Step 1: Center-crop square and scale smoothly to targetPx x targetPx
            val cropSize = minOf(w, h)
            val cropX = (w - cropSize) / 2
            val cropY = (h - cropSize) / 2
            val cropped = Bitmap.createBitmap(source, cropX, cropY, cropSize, cropSize)
            val scaled = if (cropSize != targetPx) {
                Bitmap.createScaledBitmap(cropped, targetPx, targetPx, true)
            } else {
                cropped
            }

            // Step 2: Render into rounded-rect or circle with anti-aliased BitmapShader
            val out = Bitmap.createBitmap(targetPx, targetPx, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            }
            val rect = RectF(0f, 0f, targetPx.toFloat(), targetPx.toFloat())
            if (isCircle) {
                val r = targetPx / 2f
                canvas.drawCircle(r, r, r, paint)
            } else {
                val cornerRadius = targetPx * 0.16f
                canvas.drawRoundRect(rect, cornerRadius, cornerRadius, paint)
            }
            if (scaled != source && scaled != out) {
                scaled.recycle()
            }
            if (cropped != source && cropped != scaled && cropped != out) {
                cropped.recycle()
            }
            out
        } catch (_: Throwable) {
            source
        }
    }

    private fun resolveAppLabel(context: Context, packageName: String): String {
        if (packageName.isBlank()) return "Unknown App"
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName.substringAfterLast('.')
        } catch (_: Throwable) {
            packageName
        }
    }

    private fun dispatchState() {
        val snapshot = currentState
        mainHandler.post {
            listeners.forEach { it(snapshot) }
        }
    }
}
