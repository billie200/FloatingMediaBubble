plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1

android {
    namespace = "com.example.floatingmediacontroller"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.floatingmediacontroller"
        minSdk = 26
        targetSdk = 35
        versionCode = 200 + runNumber
        versionName = "3.0.$runNumber"

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("persistent.jks")
            storePassword = "android"
            keyAlias = "floatingmedia"
            keyPassword = "android"
        }
        create("release") {
            storeFile = file("persistent.jks")
            storePassword = "android"
            keyAlias = "floatingmedia"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Zero third-party bloat
}
