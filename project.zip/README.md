# FloatingMediaController (Floating Media Bubble)

A super-lightweight, low-RAM Material Design 3 floating media overlay bubble for Android 8.0 through Android 16 (API 26–35) supporting both `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit) devices.

## Features
- **Dark Translucent Material 3 Bubble**: Uses native XML `WindowManager` views (`#CC14161C` glass pill) instead of heavy Compose runtimes, keeping RAM usage under ~15 MB.
- **Little Circular Album Art**: Automatically downscaled to 96×96 px in memory.
  - **Single Tap on Album Art**: Collapses the pill into a mini floating bubble (showing only Album Art, `-5s`, `Play/Pause`, and `+5s`), or expands it back to show the scrolling marquee track title.
  - **Long Press on Album Art**: Vibrates gently and closes/dismisses the floating bubble.
- **±5 Second Seek + Track Skip**:
  - **Single Tap `-5s` / `+5s`**: Rewinds or fast-forwards the active media by 5 seconds (`seekTo`).
  - **Long Press `-5s` / `+5s`**: Skips to the Previous or Next track.
- **Universal Media Compatibility**: Works with Spotify, YouTube Music, Apple Music, podcasts, Chrome/Firefox, and local players via `MediaSessionManager`.
